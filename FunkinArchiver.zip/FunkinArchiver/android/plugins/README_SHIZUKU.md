# ShizukuBridge — plugin Android v2

El módulo contiene el código fuente del puente nativo. **El AAR no está incluido ni se considera compilado**: debe generarse con Android Studio/Gradle antes de exportar la APK.

## Compilar e instalar el archivo del plugin

1. Abre `android/shizuku-build/` en Android Studio.
2. Usa JDK 17 y Android SDK Platform 35; sincroniza Gradle.
3. Ejecuta `:ShizukuBridge:assembleRelease`.
4. Copia el resultado `android/plugins/ShizukuBridge/build/outputs/aar/ShizukuBridge-release.aar` a esta ruta exacta dentro del proyecto Godot:

   `android/plugins/ShizukuBridge/bin/ShizukuBridge.aar`

5. En Godot, confirma que esté activado `Funkin Archiver Shizuku Bridge` en **Project > Project Settings > Plugins**. Ya está marcado como habilitado en `project.godot`.
6. Instala/actualiza la plantilla Android de exportación, crea un preset Android y activa **Use Gradle Build**.
7. Exporta e instala la APK. En el teléfono, inicia Shizuku y concede el permiso cuando Funkin' Archiver lo solicite.

La dependencia de Godot del módulo se fija a `4.7.2.stable`; compílalo con la misma versión de Godot que usas para exportar. Shizuku API/provider: `13.1.5`.

## Métodos expuestos a GDScript

- `isShizukuAvailable()` y `hasShizukuPermission()`
- `requestShizukuPermission()`
- `listAndroidData()` y `listPath(path)`
- `makeDirectory(path)`, `deletePath(path)`, `renamePath(source, destination)`

El servicio remoto implementa un Binder AIDL, como requiere `Shizuku.bindUserService`, y usa identidad shell (UID 2000) si Shizuku se inició mediante ADB. El acceso efectivo a `/storage/emulated/0/Android/data` depende de Android/ROM; no se promete acceso universal.

## Estado de esta entrega

El código fuente está integrado y el export plugin agrega el proveedor y el descriptor de Godot cuando encuentra el AAR. **No se incluye un AAR precompilado**, porque este entorno no dispone de Godot, Gradle ni Android SDK para compilarlo y probarlo. La vista de prueba de Android/data sigue separada del backend general de archivos.
