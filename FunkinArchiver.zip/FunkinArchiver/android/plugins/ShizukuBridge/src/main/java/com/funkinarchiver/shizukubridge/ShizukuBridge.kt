package com.funkinarchiver.shizukubridge

import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import android.os.RemoteException
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.UsedByGodot
import rikka.shizuku.Shizuku

class ShizukuBridge(godot: Godot) : GodotPlugin(godot) {
    private var fileService: IShizukuFs? = null
    private var bindRequested = false

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        if (grantResult == PackageManagerCompat.PERMISSION_GRANTED) bindFileService()
    }

    private val binderListener = Shizuku.OnBinderReceivedListener { bindFileService() }
    private val binderDeadListener = Shizuku.OnBinderDeadListener { fileService = null; bindRequested = false }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            fileService = IShizukuFs.Stub.asInterface(binder)
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            fileService = null
        }
    }

    override fun getPluginName() = "ShizukuBridge"
    override fun getPluginMethods() = setOf("isShizukuAvailable", "hasShizukuPermission", "requestShizukuPermission", "listAndroidData", "listPath", "makeDirectory", "deletePath", "renamePath")
    override fun onMainCreate(activity: android.app.Activity): android.view.View? {
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListener(binderListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        if (Shizuku.pingBinder()) bindFileService()
        return null
    }

    @UsedByGodot fun isShizukuAvailable(): Boolean = Shizuku.pingBinder()
    @UsedByGodot fun hasShizukuPermission(): Boolean = Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManagerCompat.PERMISSION_GRANTED

    @UsedByGodot fun requestShizukuPermission() {
        if (!Shizuku.pingBinder()) return
        if (Shizuku.checkSelfPermission() == PackageManagerCompat.PERMISSION_GRANTED) bindFileService()
        else Shizuku.requestPermission(4102)
    }

    @UsedByGodot fun listAndroidData(): String = listPath("/storage/emulated/0/Android/data")

    @UsedByGodot fun listPath(path: String): String {
        val service = fileService ?: return "{\"ok\":false,\"error\":\"SERVICE_NOT_CONNECTED\"}"
        return try { service.listChildren(path) } catch (_: RemoteException) { "{\"ok\":false,\"error\":\"REMOTE_ERROR\"}" }
    }

    @UsedByGodot fun makeDirectory(path: String): Int = try { fileService?.makeDirectory(path) ?: -2 } catch (_: RemoteException) { -3 }
    @UsedByGodot fun deletePath(path: String): Int = try { fileService?.deletePath(path) ?: -2 } catch (_: RemoteException) { -3 }
    @UsedByGodot fun renamePath(source: String, destination: String): Int = try { fileService?.renamePath(source, destination) ?: -2 } catch (_: RemoteException) { -3 }

    private fun bindFileService() {
        if (!Shizuku.pingBinder() || !hasShizukuPermission() || bindRequested) return
        try {
            val args = Shizuku.UserServiceArgs(ComponentName(godot.getActivity(), ShizukuFileService::class.java))
                .daemon(false)
                .tag("funkin_archiver_shizuku_fs")
                .version(1)
                .processNameSuffix("funkin_archiver_fs")
            Shizuku.bindUserService(args, connection)
            bindRequested = true
        } catch (_: Exception) {
            bindRequested = false
        }
    }

    override fun onMainDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permissionListener)
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            if (bindRequested) {
                val args = Shizuku.UserServiceArgs(ComponentName(godot.getActivity(), ShizukuFileService::class.java))
                    .daemon(false).tag("funkin_archiver_shizuku_fs").version(1).processNameSuffix("funkin_archiver_fs")
                Shizuku.unbindUserService(args, connection, true)
            }
        } catch (_: Exception) { }
        fileService = null
        bindRequested = false
    }
}

private object PackageManagerCompat { const val PERMISSION_GRANTED = 0 }
