# Funkin' Archiver

Explorador de archivos tipo ZArchiver, hecho en Godot 4.3+ (GL Compatibility), con la estetica de Funkin' Backstage.

## Abrir
1. Descomprime y abre `project.godot` en Godot 4.3 o superior.
2. Espera a que importe los assets (fuentes, png, ogg) y pulsa F5.
   En PC arranca en tu carpeta de usuario.

## Android
1. Instala Android build template: Project > Install Android Build Template.
2. Project > Export > Add > Android. En Permissions activa:
   - Read External Storage / Write External Storage (Android 10 o menos)
   - Manage External Storage (Android 11+, "Acceso a todos los archivos")
   (el nombre exacto puede variar segun la version de Godot)
3. Exporta e instala. Al abrir, la app pide permisos; en Android 11+ te lleva
   a Ajustes para dar "Acceso a todos los archivos". Hay un boton "Permisos de archivos" en el menu lateral.

## Novedades v9
- Reproductor: al tocar un audio (ogg/mp3/wav) se abre un reproductor con visualizador de espectro, barra de tiempo (arrastra para saltar), anterior/siguiente por los audios de la carpeta, y debajo las opciones (Importar a mi musica, Abrir con app, Propiedades). La musica sigue sonando al cerrarlo. El menu lateral tambien muestra un visualizador pequeno. flac/m4a no se reproducen en Godot: salen las opciones igualmente.
- Zips sin descomprimir: tocar un zip (tambien .pk3, .mcpack, .mcaddon, .mcworld, .jar) lo abre como carpeta. Navega, y al tocar un archivo: Abrir (audio en el reproductor, imagen, texto, zip dentro de zip, APK) o Extraer solo ese archivo. Boton Extraer: esta carpeta / todo aqui / todo en carpeta. Los archivos abiertos se sacan a `.funkin_archiver_tmp` (se limpia al iniciar).
- APK: tocar un .apk > Instalar. Hace falta activar el permiso "Request Install Packages" en Export > Android > Permissions, y permitir "Instalar apps desconocidas" a la app la primera vez.
- Miniaturas: las imagenes muestran una vista previa en lugar del icono (se cargan en segundo plano, solo las filas visibles, imagenes de hasta 6 MB).

## Novedades v8
- Abrir con app: toca un archivo (o Mas > Abrir con app con uno seleccionado; tambien en los menus de zip y audio). Usa `OS.shell_open`, que en Android abre el selector de apps. Necesita Godot 4.3+ y que el export incluya el FileProvider por defecto.
- Archivos ocultos: menu lateral > "Ocultos: Si/No" o el boton de las 3 lineas > Oculto (ya estaba; se guarda entre sesiones).
- Android/data y Android/obb: atajos en el menu lateral y "Ir a ruta..." para escribir una ruta (p. ej. /storage/emulated/0/Android/data/com.paquete). En Android 11+ el sistema bloquea esas carpetas a las apps normales aunque tengan "Acceso a todos los archivos", asi que puede salir vacia; en Android 10 o menos funciona normal.

## Novedades v7
- Sin botones de pestanas: ahora desliza a los lados y se ven las dos carpetas a la vez mientras arrastras (la actual sale y la otra entra). Suelta pasado el 30 % para cambiar, o antes para volver. Abajo hay 2 puntos que marcan en que pestana estas.
- Barra de carga: el microfono mide lo mismo de alto que GF/BF, y muestra el progreso real en porcentaje ("Cargando 45%"). Al terminar de cargar los ficheros desaparece al instante (sin fundido ni espera).

## Novedades v6
- Animacion de carga con el mic stand: el microfono empieza gris y se va llenando de blanco segun avanza, con GF y BF corriendo por encima (`scripts/loading_bar.gd`, assets en `assets/images/loading/`; las tiras bf_run/gf_run salen de tus atlas bf.xml/gf.xml, 8 poses cada una).
- Al abrir carpetas: solo aparece si la carga tarda mas de 0.35 s (en carpetas pequenas no se ve). Es una tarjeta abajo que no bloquea la lista; muestra "Cargando N / total".
- En copiar, mover, borrar, comprimir y extraer: la ventana de progreso usa la misma barra.

## Novedades v5
- Doble pestana: dos pestanas con su propia carpeta. Desliza a izquierda/derecha sobre la lista (o toca las pestanas de arriba) para cambiar. El portapapeles se comparte: copia en una y pega en la otra. Se activa/desactiva en Menu > Interfaz.
- Rotacion: la app gira (orientation=sensor). En apaisado la cuadricula usa mas columnas.
- Sin intro: se desactiva la imagen de arranque de Godot (boot splash) y el fondo de arranque es oscuro.
- Android: en Export > Android revisa que "Screen > Orientation" este en Sensor, y usa Godot 4.3+.

## Novedades v4
- Boton de las 3 lineas (arriba a la derecha) abre el panel **Ver / Ordenar** como en ZArchiver: Detallado, Compacto, Cuadricula, Oculto; ordenar por Nombre, Tamano, Fecha, Tipo y Desc. Se guarda entre sesiones. "Actualizar" ahora esta en el menu lateral.
- Carga instantanea: la lista es virtual (solo se dibujan las filas visibles) y los nombres salen al momento; tamano, fecha y "N elementos" se rellenan en segundo plano por lotes.
- Se mantiene la estetica Backstage en las filas y paneles.

## Novedades
- Conserva la estetica Funkin' Backstage (paneles oscuros, bordes blancos, migas de pan, menu lateral) con toques de ZArchiver: "N elementos" y fecha en cada fila, boton flotante (+) para crear, "Pulse atras para salir" y lugares como Tarjeta SD / Musica en el menu lateral.
- Menu lateral > Interfaz: color de carpetas (por defecto blanco), boton flotante y fondo animado (se guardan).
- Listado de carpetas en un hilo y filas cargadas por paginas (arregla el cuelgue/crash en carpetas grandes como Descargas). El log queda en `user://archiver.log` (menu lugares > Datos de la app).
- Musica custom: toca un audio (.ogg/.mp3/.wav) > "Importar a mi musica" o "Reproducir ahora". Tambien: seleccion > Mas > "Importar como musica", o Menu > Mi musica > "Importar musica". Las pistas se copian a `user://music` y se reproducen en bucle de lista (anterior/siguiente/pausa).
- Para cargar .ogg en runtime hace falta Godot 4.3+.

## Uso
- Tocar carpeta: abrir. Tocar .zip: menu (extraer aqui / en carpeta / ver contenido).
- Mantener pulsado: modo seleccion. Barra inferior: Copiar, Cortar, Borrar, ZIP, Mas.
- Copiar/Cortar y luego "Pegar aqui" en otra carpeta.
- Botones de arriba: menu lateral, buscar, nuevo (carpeta/archivo), ordenar.
- Boton atras de Android: cierra menus, sale de la seleccion o sube de carpeta.

## Estructura
- scripts/main.gd   UI y logica
- scripts/fs_ops.gd copiar, mover, borrar, ZIP (corren en un hilo)
- scripts/bskin.gd   tema Backstage (colores, fuentes, estilos)
- scripts/ico.gd    iconos dibujados en codigo

## Limitaciones conocidas
- Solo ZIP (Godot trae ZIPReader/ZIPPacker). 7z/RAR/TAR requeririan una libreria nativa (GDExtension).
- Extraer carga cada archivo del zip entero en memoria (ok para archivos de hasta cientos de MB).
- Al ordenar por tamano/fecha el orden final se aplica cuando terminan de calcularse los detalles.
- Musica custom: solo ogg, mp3 y wav PCM 8/16-bit (flac/m4a no).


## Cambios de la revision v10

- El fondo principal ahora es estatico.
- La musica importada queda guardada y la ultima pista seleccionada vuelve a sonar al iniciar.
- La primera pista importada se selecciona automaticamente como musica del menu.
- Se agregaron controles de escala para texto e informacion de archivos en Ajustes.
- Las listas principales, barra lateral y navegador ZIP usan desplazamiento automatico.

### Acceso a Android/data mediante Shizuku

La base de integración nativa se incorporó en v13. Consulta la sección de v13 y el archivo `android/plugins/README_SHIZUKU.md` para compilarla y probarla; el AAR no viene precompilado.

El navegador ZIP actual es virtual (lee el contenido sin extraerlo) y permite entrar en subcarpetas, volver al nivel anterior y extraer el nivel actual o el archivo completo. Todavia no es un montaje ZIP nativo idéntico a una carpeta del sistema.


## v11 settings screen update (preview)

- Settings now open as a dedicated full-screen page instead of a small modal.
- Font scale and file-information scale use live adjustable sliders (80%–160%).
- Values are saved in the existing `user://settings.cfg` configuration.
- The background remains static.

The Shizuku Android bridge is not included as a compiled/verified plugin in this preview.
It requires a Godot Android Gradle export and device-side testing before it can be called functional.


## Revision v12 (integracion y navegacion)

- Ajustes separa los controles de opciones y ficheros. Se mantienen los deslizadores de texto e informacion y se añade altura de filas (80–140%), guardada entre sesiones y aplicada a lista, compacto y cuadricula.
- El navegador ZIP ahora muestra migas de pan pulsables por nivel, contador de carpetas/archivos y nombres de carpeta con `/`, para que la navegacion se parezca mas a abrir una carpeta normal.
- Shizuku: se detecta si existe el singleton `ShizukuBridge`, pero esta entrega no incorpora el plugin Kotlin/Android ni afirma que Android/data ya sea accesible. Para completar esa parte se necesita implementar y compilar el puente nativo con la API oficial de Shizuku, gestionar la autorizacion del usuario y probar las operaciones de lectura/escritura en dispositivo real.

## Revision v13 — base nativa de Shizuku para Android 15

- Se añadió el código fuente del plugin Android v2 `ShizukuBridge`, basado en la API oficial de Shizuku y en un `UserService` con identidad shell (ADB/UID 2000).
- El menú `Shizuku / Android data` ahora comprueba si Shizuku está iniciado, consulta el permiso, permite solicitarlo y ofrece una prueba de listado de `/storage/emulated/0/Android/data`.
- El servicio expone operaciones nativas de listado, creación de carpetas, borrado y renombrado.
- Se agregó un proyecto Gradle en `android/shizuku-build/` para compilar el AAR y el empaquetador de plugin Godot en `addons/shizuku_bridge/`.

**Importante:** esta revisión entrega la integración de código fuente, no una APK ni un AAR compilado. No se pudo compilar ni probar en un teléfono desde este entorno. Primero hay que compilar `ShizukuBridge.aar` siguiendo `android/plugins/README_SHIZUKU.md`, exportar con Gradle y probar en Android 15. La prueba de listado aparece en un menú independiente; la navegación normal y todas las operaciones de `FsOps` todavía no están conectadas al servicio Shizuku. Android puede seguir denegando algunas rutas según la versión del sistema y el fabricante.
