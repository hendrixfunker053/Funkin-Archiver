@tool
extends EditorExportPlugin

const AAR_PATH := "res://android/plugins/ShizukuBridge/bin/ShizukuBridge.aar"

func _get_android_libraries(_platform: EditorExportPlatform, _debug: bool) -> PackedStringArray:
	if FileAccess.file_exists(AAR_PATH):
		return PackedStringArray([AAR_PATH])
	return PackedStringArray()

func _get_android_dependencies(_platform: EditorExportPlatform, _debug: bool) -> PackedStringArray:
	if not FileAccess.file_exists(AAR_PATH):
		return PackedStringArray()
	return PackedStringArray([
		"dev.rikka.shizuku:api:13.1.5",
		"dev.rikka.shizuku:provider:13.1.5"
	])

func _get_android_manifest_application_element_contents(_platform: EditorExportPlatform, _debug: bool) -> String:
	if not FileAccess.file_exists(AAR_PATH):
		return ""
	return """
	<provider
		android:name="rikka.shizuku.ShizukuProvider"
		android:authorities="${applicationId}.shizuku"
		android:multiprocess="false"
		android:enabled="true"
		android:exported="true"
		android:permission="android.permission.INTERACT_ACROSS_USERS_FULL" />
	<meta-data
		android:name="org.godotengine.plugin.v2.ShizukuBridge"
		android:value="com.funkinarchiver.shizukubridge.ShizukuBridge" />
	"""
