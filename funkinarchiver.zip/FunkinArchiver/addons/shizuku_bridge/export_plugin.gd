@tool
extends EditorPlugin

const ExportHandler = preload("res://addons/shizuku_bridge/export_handler.gd")

var _shizuku_exporter: EditorExportPlugin

func _enter_tree() -> void:
	_shizuku_exporter = ExportHandler.new()
	add_export_plugin(_shizuku_exporter)

func _exit_tree() -> void:
	if _shizuku_exporter != null:
		remove_export_plugin(_shizuku_exporter)
		_shizuku_exporter = null
