package com.funkinarchiver.shizukubridge;

interface IShizukuFs {
    String listChildren(String path);
    int makeDirectory(String path);
    int deletePath(String path);
    int renamePath(String source, String destination);
}
