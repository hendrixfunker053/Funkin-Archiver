package com.funkinarchiver.shizukubridge

import android.os.RemoteException
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Runs inside Shizuku's shell-UID UserService process. */
class ShizukuFileService : IShizukuFs.Stub() {
    override fun listChildren(path: String): String {
        val dir = File(path)
        if (!dir.isDirectory) return JSONObject().put("ok", false).put("error", "NOT_DIRECTORY").toString()
        val children = dir.listFiles() ?: return JSONObject().put("ok", false).put("error", "ACCESS_DENIED_OR_EMPTY").toString()
        val result = JSONArray()
        children.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() })).forEach { file ->
            result.put(JSONObject()
                .put("name", file.name)
                .put("path", file.absolutePath)
                .put("is_dir", file.isDirectory)
                .put("size", if (file.isFile) file.length() else 0L)
                .put("mtime", file.lastModified()))
        }
        return JSONObject().put("ok", true).put("items", result).toString()
    }

    override fun makeDirectory(path: String): Int = if (File(path).mkdirs()) 0 else if (File(path).isDirectory) 0 else -1
    override fun deletePath(path: String): Int = if (File(path).deleteRecursively()) 0 else -1
    override fun renamePath(source: String, destination: String): Int = if (File(source).renameTo(File(destination))) 0 else -1
}
