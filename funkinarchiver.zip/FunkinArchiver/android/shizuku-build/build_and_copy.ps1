$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
Push-Location $PSScriptRoot
try {
    gradle :ShizukuBridge:assembleRelease
    $source = Join-Path $ProjectRoot "android/plugins/ShizukuBridge/build/outputs/aar/ShizukuBridge-release.aar"
    $targetDir = Join-Path $ProjectRoot "android/plugins/ShizukuBridge/bin"
    New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
    Copy-Item -Force $source (Join-Path $targetDir "ShizukuBridge.aar")
    Write-Host "AAR copiado a android/plugins/ShizukuBridge/bin/ShizukuBridge.aar"
} finally { Pop-Location }
