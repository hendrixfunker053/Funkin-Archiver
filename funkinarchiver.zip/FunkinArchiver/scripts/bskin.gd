class_name BSkin
extends RefCounted
## Estética Funkin' Backstage: paneles oscuros, bordes blancos, lila y amarillo.

const DARK := Color("1a161f")
const PANEL := Color("1d1923")
const PURPLE_BG := Color("4a3b4d")
const LILAC := Color("6f7399")
const LILAC_DARK := Color("4a4d6b")
const LILAC_TEXT := Color("8b8fbf")
const YELLOW := Color("ffd54f")
const OFFWHITE := Color("f5f2ea")
const PINK := Color("ff7b9c")
const BLUE := Color("6ec6ff")
const GREEN := Color("8be28b")

static var font_title: FontFile
static var font_body: FontFile


static func box(fill: Color, border: Color = OFFWHITE, bw: int = 5, radius: int = 22, pad: int = 18) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = fill
	s.set_border_width_all(bw)
	s.border_color = border
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(pad)
	s.anti_aliasing = true
	return s


static func load_fonts() -> void:
	if font_title != null:
		return
	font_title = load("res://assets/fonts/funkin.otf")
	font_body = load("res://assets/fonts/FunkinOptions.otf")
	# Glifos que faltan (¿ ¡ … ›) caen a la fuente del sistema.
	font_body.fallbacks = [SystemFont.new()]
	font_title.fallbacks = [font_body]


static func make_theme() -> Theme:
	load_fonts()
	var t := Theme.new()
	t.default_font = font_body
	t.default_font_size = 40

	# Labels
	t.set_font("font", "Label", font_body)
	t.set_font_size("font_size", "Label", 40)
	t.set_color("font_color", "Label", OFFWHITE)

	# Botones
	t.set_font("font", "Button", font_title)
	t.set_font_size("font_size", "Button", 44)
	t.set_color("font_color", "Button", OFFWHITE)
	t.set_color("font_hover_color", "Button", Color.WHITE)
	t.set_color("font_pressed_color", "Button", DARK)
	t.set_color("font_focus_color", "Button", OFFWHITE)
	t.set_stylebox("normal", "Button", box(PANEL))
	t.set_stylebox("hover", "Button", box(LILAC_DARK))
	t.set_stylebox("pressed", "Button", box(YELLOW, OFFWHITE))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_stylebox("disabled", "Button", box(PANEL, LILAC_DARK))

	# Campo de texto (lila, como el buscador del sitio)
	t.set_font("font", "LineEdit", font_body)
	t.set_font_size("font_size", "LineEdit", 42)
	t.set_color("font_color", "LineEdit", Color.WHITE)
	t.set_color("font_placeholder_color", "LineEdit", Color("b9bce0"))
	t.set_color("caret_color", "LineEdit", YELLOW)
	t.set_stylebox("normal", "LineEdit", box(LILAC, OFFWHITE, 5, 20, 20))
	t.set_stylebox("focus", "LineEdit", box(LILAC, YELLOW, 6, 20, 20))

	# Paneles
	t.set_stylebox("panel", "PanelContainer", box(PANEL))
	t.set_stylebox("panel", "Panel", box(PANEL))

	# Progreso
	var bg := box(DARK, OFFWHITE, 4, 14, 0)
	var fill := box(YELLOW, YELLOW, 0, 14, 0)
	t.set_stylebox("background", "ProgressBar", bg)
	t.set_stylebox("fill", "ProgressBar", fill)
	t.set_font("font", "ProgressBar", font_body)
	t.set_font_size("font_size", "ProgressBar", 30)
	t.set_color("font_color", "ProgressBar", DARK)

	# Scroll
	var grab := box(LILAC, LILAC, 0, 8, 0)
	grab.content_margin_left = 10
	grab.content_margin_right = 10
	var scr := StyleBoxEmpty.new()
	t.set_stylebox("scroll", "VScrollBar", scr)
	t.set_stylebox("grabber", "VScrollBar", grab)
	t.set_stylebox("grabber_highlight", "VScrollBar", grab)
	t.set_stylebox("grabber_pressed", "VScrollBar", box(YELLOW, YELLOW, 0, 8, 0))
	t.set_stylebox("scroll", "HScrollBar", scr)
	t.set_stylebox("grabber", "HScrollBar", grab)
	t.set_stylebox("grabber_highlight", "HScrollBar", grab)
	t.set_stylebox("grabber_pressed", "HScrollBar", box(YELLOW, YELLOW, 0, 8, 0))
	return t
