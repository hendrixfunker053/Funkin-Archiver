class_name FsOps
extends RefCounted
## Operaciones de archivos: listar, copiar, mover, borrar, comprimir y extraer ZIP.
## Las operaciones largas se pueden ejecutar en un hilo; `on_progress(p: float, label: String)`.

var total: int = 0
var done: int = 0
var on_progress: Callable = Callable()

const IMAGE_EXT := ["png", "jpg", "jpeg", "webp", "bmp", "svg"]
const AUDIO_EXT := ["ogg", "mp3", "wav", "flac", "m4a"]
const ARCHIVE_EXT := ["zip", "pk3", "mcpack", "mcaddon", "mcworld", "jar"]


func _tick(label: String) -> void:
	done += 1
	if on_progress.is_valid():
		on_progress.call(float(done) / float(maxi(total, 1)), label)


# ---------- utilidades estáticas ----------

static func join(a: String, b: String) -> String:
	if a.ends_with("/"):
		return a + b
	return a + "/" + b


static func is_inside(child: String, parent: String) -> bool:
	var p := parent.rstrip("/")
	return child == p or child.begins_with(p + "/")


static func ext_of(path: String) -> String:
	return path.get_extension().to_lower()


static func kind_of(path: String, is_dir: bool) -> String:
	if is_dir:
		return "folder"
	var e := ext_of(path)
	if e == "apk":
		return "apk"
	if e in ARCHIVE_EXT:
		return "zip"
	if e in IMAGE_EXT:
		return "image"
	if e in AUDIO_EXT:
		return "audio"
	return "file"


static func format_size(bytes: int) -> String:
	var units := ["B", "KB", "MB", "GB", "TB"]
	var v := float(bytes)
	var i := 0
	while v >= 1024.0 and i < units.size() - 1:
		v /= 1024.0
		i += 1
	if i == 0:
		return "%d B" % bytes
	return "%.1f %s" % [v, units[i]]


static func format_time(unix: int) -> String:
	if unix <= 0:
		return "-"
	var bias: int = int(Time.get_time_zone_from_system().get("bias", 0))
	var d := Time.get_datetime_dict_from_unix_time(unix + bias * 60)
	var h: int = d.hour
	var ap := "a.m." if h < 12 else "p.m."
	h = h % 12
	if h == 0:
		h = 12
	return "%d/%d/%d %d:%02d %s" % [d.day, d.month, d.year, h, d.minute, ap]


static func file_size(path: String) -> int:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return 0
	var n := f.get_length()
	f.close()
	return n


static func unique_path(path: String) -> String:
	if not FileAccess.file_exists(path) and not DirAccess.dir_exists_absolute(path):
		return path
	var dir := path.get_base_dir()
	var base := path.get_file().get_basename()
	var ext := path.get_extension()
	var n := 1
	while true:
		var fname := "%s (%d)" % [base, n]
		if ext != "":
			fname += "." + ext
		var cand := join(dir, fname)
		if not FileAccess.file_exists(cand) and not DirAccess.dir_exists_absolute(cand):
			return cand
		n += 1
	return path


static func safe_name(n: String) -> String:
	var out := ""
	for i in n.length():
		var c := n.unicode_at(i)
		if c < 32 or c == 127 or (c >= 0xD800 and c <= 0xDFFF):
			out += "?"
		else:
			out += n[i]
	if out.length() > 140:
		out = out.substr(0, 137) + "..."
	return out


static func list_dir(path: String, show_hidden: bool = false, extra: bool = false) -> Array:
	var out: Array = []
	var d := DirAccess.open(path)
	if d == null:
		return out
	d.include_hidden = show_hidden
	d.list_dir_begin()
	var n := d.get_next()
	while n != "":
		var full := join(path, n)
		var is_dir := d.current_is_dir()
		var cnt := -1
		if is_dir and extra:
			var sub := DirAccess.open(full)
			if sub != null:
				sub.include_hidden = show_hidden
				cnt = sub.get_files().size() + sub.get_directories().size()
		out.append({
			"name": n,
			"disp": safe_name(n),
			"path": full,
			"is_dir": is_dir,
			"size": 0 if is_dir else file_size(full),
			"mtime": FileAccess.get_modified_time(full),
			"count": cnt,
		})
		n = d.get_next()
	d.list_dir_end()
	return out


static func list_names(path: String, show_hidden: bool = false) -> Array:
	## Solo nombres y si es carpeta: instantaneo incluso con miles de archivos.
	var out: Array = []
	var d := DirAccess.open(path)
	if d == null:
		return out
	d.include_hidden = show_hidden
	d.list_dir_begin()
	var n := d.get_next()
	while n != "":
		out.append({
			"name": n,
			"disp": safe_name(n),
			"path": join(path, n),
			"is_dir": d.current_is_dir(),
			"size": 0,
			"mtime": 0,
			"count": -1,
			"ok": false,
		})
		n = d.get_next()
	d.list_dir_end()
	return out


static func sort_default(arr: Array) -> void:
	arr.sort_custom(func(a, b):
		if a.is_dir != b.is_dir:
			return a.is_dir
		return String(a.name).naturalnocasecmp_to(String(b.name)) < 0)


static func details(path: String, is_dir: bool, show_hidden: bool) -> Array:
	## Devuelve [tamano, fecha, conteo]. Se calcula aparte, en lotes.
	var cnt := -1
	var sz := 0
	if is_dir:
		var sub := DirAccess.open(path)
		if sub != null:
			sub.include_hidden = show_hidden
			cnt = sub.get_files().size() + sub.get_directories().size()
	else:
		sz = file_size(path)
	return [sz, FileAccess.get_modified_time(path), cnt]


static func dir_size(path: String) -> int:
	var total_size := 0
	for e in list_dir(path, true):
		if e.is_dir:
			total_size += dir_size(e.path)
		else:
			total_size += e.size
	return total_size


static func zip_list(zip_path: String) -> PackedStringArray:
	var r := ZIPReader.new()
	if r.open(zip_path) != OK:
		return PackedStringArray()
	var files := r.get_files()
	r.close()
	return files


# ---------- conteo ----------

func count_files(paths: Array, only_files: bool = false) -> int:
	var n := 0
	for p in paths:
		n += _count(p, only_files)
	return n


func _count(path: String, only_files: bool) -> int:
	if DirAccess.dir_exists_absolute(path):
		var n := 0 if only_files else 1
		for e in list_dir(path, true):
			n += _count(e.path, only_files)
		return n
	return 1


# ---------- copiar / mover / borrar ----------

func copy_any(src: String, dst_dir: String) -> int:
	var dst := unique_path(join(dst_dir, src.get_file()))
	if DirAccess.dir_exists_absolute(src):
		return _copy_dir(src, dst)
	return _copy_file(src, dst)


func _copy_file(src: String, dst: String) -> int:
	var err: int = DirAccess.copy_absolute(src, dst)
	_tick(src.get_file())
	return err


func _copy_dir(src: String, dst: String) -> int:
	var result: int = DirAccess.make_dir_recursive_absolute(dst)
	_tick(src.get_file())
	if result != OK:
		return result
	for e in list_dir(src, true):
		var target := join(dst, e.name)
		var r: int = _copy_dir(e.path, target) if e.is_dir else _copy_file(e.path, target)
		if r != OK:
			result = r
	return result


func move_any(src: String, dst_dir: String) -> int:
	if src.get_base_dir() == dst_dir.rstrip("/") or src.get_base_dir() == dst_dir:
		_tick(src.get_file())
		return OK
	var dst := unique_path(join(dst_dir, src.get_file()))
	var err: int = DirAccess.rename_absolute(src, dst)
	if err != OK:
		# Distinto volumen: copiar y luego borrar
		var saved_total := total
		var saved_done := done
		var cb := on_progress
		on_progress = Callable()
		if DirAccess.dir_exists_absolute(src):
			err = _copy_dir(src, dst)
		else:
			err = _copy_file(src, dst)
		on_progress = cb
		total = saved_total
		done = saved_done
		if err == OK:
			err = delete_any(src, false)
	_tick(src.get_file())
	return err


func delete_any(path: String, tick: bool = true) -> int:
	var result: int = OK
	if DirAccess.dir_exists_absolute(path):
		for e in list_dir(path, true):
			var r: int = delete_any(e.path, tick)
			if r != OK:
				result = r
	var err: int = DirAccess.remove_absolute(path)
	if tick:
		_tick(path.get_file())
	return err if err != OK else result


# ---------- ZIP ----------

func compress(paths: Array, zip_path: String) -> int:
	var z := ZIPPacker.new()
	var err: int = z.open(zip_path)
	if err != OK:
		return err
	for p in paths:
		_zip_add(z, p, p.get_file(), zip_path)
	z.close()
	return OK


func _zip_add(z: ZIPPacker, abs_path: String, rel: String, zip_path: String) -> void:
	if abs_path == zip_path:
		return
	if DirAccess.dir_exists_absolute(abs_path):
		var children := list_dir(abs_path, true)
		if children.is_empty():
			z.start_file(rel + "/")
			z.close_file()
		for e in children:
			_zip_add(z, e.path, rel + "/" + e.name, zip_path)
		return
	var f := FileAccess.open(abs_path, FileAccess.READ)
	if f == null:
		_tick(rel)
		return
	z.start_file(rel)
	var flen := f.get_length()
	while f.get_position() < flen:
		var buf := f.get_buffer(1 << 20)
		if buf.size() == 0:
			break
		z.write_file(buf)
	z.close_file()
	f.close()
	_tick(rel)


func extract(zip_path: String, dst_dir: String, prefix: String = "") -> int:
	## prefix "" = todo. "dir/" = esa carpeta (se crea dst/dir/...). "dir/a.txt" = solo ese archivo.
	var r := ZIPReader.new()
	var err: int = r.open(zip_path)
	if err != OK:
		return err
	var files: PackedStringArray = r.get_files()
	var picked: Array = []
	for f in files:
		if prefix == "" or f == prefix or (prefix.ends_with("/") and f.begins_with(prefix)):
			picked.append(f)
	total = picked.size()
	done = 0
	DirAccess.make_dir_recursive_absolute(dst_dir)
	var cut := 0
	var base := ""
	if prefix != "":
		if prefix.ends_with("/"):
			base = prefix.rstrip("/").get_file() + "/"
			cut = prefix.length()
		else:
			base = ""
			cut = prefix.length() - prefix.get_file().length()
	for f in picked:
		var clean: String = (base + f.substr(cut)).lstrip("/") if prefix != "" else f.lstrip("/")
		var unsafe := false
		for seg in clean.split("/"):
			if seg == "..":
				unsafe = true
		if unsafe or clean == "":
			_tick(f)
			continue
		var out := join(dst_dir, clean)
		if clean.ends_with("/"):
			DirAccess.make_dir_recursive_absolute(out)
		else:
			DirAccess.make_dir_recursive_absolute(out.get_base_dir())
			var data := r.read_file(f)
			var w := FileAccess.open(out, FileAccess.WRITE)
			if w != null:
				w.store_buffer(data)
				w.close()
		_tick(f)
	r.close()
	return OK

