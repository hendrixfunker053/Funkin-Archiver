class_name Ico
extends Control
## Iconos vectoriales dibujados en código (no hacen falta más assets).

var kind: String = "file"
var col: Color = Color("f5f2ea")


func _init(k: String = "file", c: Color = Color("f5f2ea"), s: float = 64.0) -> void:
	kind = k
	col = c
	custom_minimum_size = Vector2(s, s)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func set_kind(k: String, c: Color = Color("f5f2ea")) -> void:
	kind = k
	col = c
	queue_redraw()


func _p(x: float, y: float) -> Vector2:
	return Vector2(size.x * x, size.y * y)


func _line(a: Vector2, b: Vector2, th: float = 0.09) -> void:
	draw_line(_p(a.x, a.y), _p(b.x, b.y), col, size.x * th, true)


func _poly(pts: Array, c: Color) -> void:
	var arr := PackedVector2Array()
	for v in pts:
		arr.append(_p(v[0], v[1]))
	draw_colored_polygon(arr, c)


func _file_body() -> void:
	_poly([[.2, .08], [.62, .08], [.82, .28], [.82, .92], [.2, .92]], col)
	_poly([[.62, .08], [.62, .28], [.82, .28]], col.darkened(0.35))


func _draw() -> void:
	var w := size.x
	var h := size.y
	var dark := Color("1a161f")
	match kind:
		"menu":
			for i in 3:
				_line(Vector2(.12, .25 + .25 * i), Vector2(.88, .25 + .25 * i), .1)
		"search":
			draw_arc(_p(.42, .42), w * .28, 0, TAU, 32, col, w * .09, true)
			_line(Vector2(.63, .63), Vector2(.88, .88), .1)
		"folder":
			_poly([[.08, .2], [.4, .2], [.5, .32], [.92, .32], [.92, .82], [.08, .82]], col)
			draw_rect(Rect2(w * .16, h * .4, w * .3, h * .05), Color(1, 1, 1, 0.55))
		"dots":
			for yy in [.2, .5, .8]:
				draw_circle(_p(.5, yy), w * .08, col)
		"tri":
			_poly([[.15, .3], [.85, .3], [.5, .78]], col)
		"arrow":
			_line(Vector2(.12, .5), Vector2(.88, .5), .1)
			_line(Vector2(.12, .5), Vector2(.44, .18), .1)
			_line(Vector2(.12, .5), Vector2(.44, .82), .1)
		"next":
			_poly([[.2, .2], [.7, .5], [.2, .8]], col)
			draw_rect(Rect2(w * .74, h * .2, w * .1, h * .6), col)
		"prev":
			_poly([[.8, .2], [.3, .5], [.8, .8]], col)
			draw_rect(Rect2(w * .16, h * .2, w * .1, h * .6), col)
		"file":
			_file_body()
		"zip":
			_file_body()
			for i in 5:
				draw_rect(Rect2(w * (.44 + (i % 2) * .07), h * (.34 + i * .1), w * .08, h * .06), dark)
		"apk":
			_file_body()
			draw_arc(_p(.5, .6), w * .17, PI, TAU, 16, dark, w * .05, true)
			draw_circle(_p(.43, .55), w * .018, dark)
			draw_circle(_p(.57, .55), w * .018, dark)
			draw_rect(Rect2(w * .33, h * .6, w * .34, h * .16), dark)
		"image":
			draw_rect(Rect2(w * .1, h * .18, w * .8, h * .64), col, false, w * .06)
			draw_circle(_p(.32, .38), w * .08, col)
			_poly([[.14, .78], [.4, .5], [.55, .66], [.68, .52], [.86, .78]], col)
		"audio":
			draw_circle(_p(.35, .75), w * .14, col)
			_line(Vector2(.47, .72), Vector2(.47, .2), .07)
			_line(Vector2(.47, .2), Vector2(.8, .34), .09)
		"back":
			_line(Vector2(.65, .15), Vector2(.3, .5), .11)
			_line(Vector2(.3, .5), Vector2(.65, .85), .11)
		"up":
			_line(Vector2(.15, .65), Vector2(.5, .3), .11)
			_line(Vector2(.5, .3), Vector2(.85, .65), .11)
		"check":
			_line(Vector2(.18, .55), Vector2(.42, .76), .12)
			_line(Vector2(.42, .76), Vector2(.84, .26), .12)
		"play":
			_poly([[.25, .15], [.85, .5], [.25, .85]], col)
		"pause":
			draw_rect(Rect2(w * .22, h * .16, w * .18, h * .68), col)
			draw_rect(Rect2(w * .6, h * .16, w * .18, h * .68), col)
		"sound", "mute":
			_poly([[.1, .38], [.3, .38], [.5, .2], [.5, .8], [.3, .62], [.1, .62]], col)
			if kind == "sound":
				draw_arc(_p(.5, .5), w * .22, -0.8, 0.8, 12, col, w * .07, true)
				draw_arc(_p(.5, .5), w * .36, -0.8, 0.8, 12, col, w * .07, true)
			else:
				_line(Vector2(.62, .36), Vector2(.88, .64), .08)
				_line(Vector2(.88, .36), Vector2(.62, .64), .08)
		"close":
			_line(Vector2(.2, .2), Vector2(.8, .8), .1)
			_line(Vector2(.8, .2), Vector2(.2, .8), .1)
		"plus":
			_line(Vector2(.5, .15), Vector2(.5, .85), .1)
			_line(Vector2(.15, .5), Vector2(.85, .5), .1)
		"sort":
			_line(Vector2(.12, .25), Vector2(.88, .25), .09)
			_line(Vector2(.12, .5), Vector2(.65, .5), .09)
			_line(Vector2(.12, .75), Vector2(.42, .75), .09)
		"viewmenu":
			for i in 3:
				draw_circle(_p(.14, .25 + .25 * i), w * .06, col)
				_line(Vector2(.3, .25 + .25 * i), Vector2(.9, .25 + .25 * i), .08)
		"view_detail":
			for i in 3:
				draw_rect(Rect2(w * .1, h * (.12 + .3 * i), w * .24, h * .2), col)
				draw_rect(Rect2(w * .42, h * (.12 + .3 * i), w * .48, h * .2), col)
		"view_compact":
			for i in 4:
				draw_circle(_p(.14, .15 + .23 * i), w * .05, col)
				_line(Vector2(.3, .15 + .23 * i), Vector2(.9, .15 + .23 * i), .07)
		"view_grid":
			for i in 9:
				draw_rect(Rect2(w * (.1 + (i % 3) * .29), h * (.1 + floorf(i / 3.0) * .29), w * .21, h * .21), col)
		"hidden":
			draw_rect(Rect2(w * .12, h * .12, w * .76, h * .76), col, false, w * .07)
			_poly([[.12, .12], [.5, .12], [.5, .88], [.12, .88]], col)
		"sort_az":
			draw_string(ThemeDB.fallback_font, _p(.04, .68), "AZ", HORIZONTAL_ALIGNMENT_LEFT, w * .92, int(h * .52), col)
		"sort_size":
			draw_rect(Rect2(w * .12, h * .55, w * .2, h * .3), col)
			draw_rect(Rect2(w * .4, h * .35, w * .2, h * .5), col)
			draw_rect(Rect2(w * .68, h * .15, w * .2, h * .7), col)
		"sort_date":
			draw_rect(Rect2(w * .12, h * .2, w * .76, h * .68), col, false, w * .07)
			draw_rect(Rect2(w * .12, h * .2, w * .76, h * .18), col)
			draw_rect(Rect2(w * .3, h * .52, w * .2, h * .2), col)
		"sort_type":
			_file_body()
		"desc":
			_line(Vector2(.3, .85), Vector2(.3, .15), .08)
			_line(Vector2(.3, .15), Vector2(.14, .32), .08)
			_line(Vector2(.3, .15), Vector2(.46, .32), .08)
			_line(Vector2(.7, .15), Vector2(.7, .85), .08)
			_line(Vector2(.7, .85), Vector2(.54, .68), .08)
			_line(Vector2(.7, .85), Vector2(.86, .68), .08)
		"home":
			_poly([[.5, .12], [.92, .5], [.8, .5], [.8, .88], [.2, .88], [.2, .5], [.08, .5]], col)
		"phone":
			draw_rect(Rect2(w * .28, h * .1, w * .44, h * .8), col, false, w * .07)
			draw_circle(_p(.5, .78), w * .035, col)
