class_name LoadingBar
extends Control
## Barra de carga "mic stand" (del mismo alto que BF/GF): el microfono gris se va llenando de blanco
## mientras GF y BF corren por encima. Todo se dibuja en codigo.
##   set_progress(0..1)            -> progreso real
##   set_indeterminate(true, tope) -> avanza solo, sin pasar de `tope`

const FRAMES := 8
const FPS := 10.0
const CHAR_SCALE := 0.42
## El microfono mide lo mismo de alto que GF (la mas alta de las dos): 382 px * CHAR_SCALE
const BAR_H := 382.0 * CHAR_SCALE
const BAR_W := BAR_H * 727.0 / 234.0
const PAD_L := 200.0
const PAD_R := 24.0
const BAR_Y := 10.0
const REF_W := PAD_L + BAR_W + PAD_R
const REF_H := BAR_H + 2.0 * BAR_Y
const RUN_MAX := BAR_W - 75.0
const GAP := 135.0
const GRAY := Color(0.42, 0.42, 0.48)

var target: float = 0.0
var shown: float = 0.0
var indeterminate: bool = false
var ind_cap: float = 0.25

var _ind_t: float = 0.0
var _t: float = 0.0
var _mic: Texture2D
var _bf: Texture2D
var _gf: Texture2D


func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(0, 160)


func _ready() -> void:
	_mic = load("res://assets/images/loading/mic-stand.png")
	_bf = load("res://assets/images/loading/bf_run.png")
	_gf = load("res://assets/images/loading/gf_run.png")


func set_progress(p: float) -> void:
	indeterminate = false
	target = clampf(p, 0.0, 1.0)


func set_indeterminate(on: bool, cap: float = 0.25) -> void:
	if on and not indeterminate:
		_ind_t = 0.0
	indeterminate = on
	ind_cap = cap


func _process(delta: float) -> void:
	_t += delta
	if indeterminate:
		_ind_t += delta
		target = ind_cap * (1.0 - exp(-_ind_t / 1.5))
	shown = lerpf(shown, target, minf(1.0, delta * 10.0))
	queue_redraw()


func _draw() -> void:
	if _mic == null or _bf == null or _gf == null:
		return
	var k := minf(size.x / REF_W, size.y / REF_H)
	if k <= 0.0:
		return
	var ox := (size.x - REF_W * k) * 0.5
	var oy := (size.y - REF_H * k) * 0.5
	var bar := Rect2(ox + PAD_L * k, oy + BAR_Y * k, BAR_W * k, BAR_H * k)
	# Microfono gris (fondo) y blanco (lo ya cargado)
	draw_texture_rect(_mic, bar, false, GRAY)
	var p := clampf(shown, 0.0, 1.0)
	if p > 0.0:
		var src_w := _mic.get_width() * p
		draw_texture_rect_region(_mic,
				Rect2(bar.position, Vector2(bar.size.x * p, bar.size.y)),
				Rect2(0.0, 0.0, src_w, _mic.get_height()))
	# GF y BF corren por encima, al frente de lo cargado
	var edge := clampf(p * BAR_W, 20.0, RUN_MAX)
	var bf_x := PAD_L + edge
	var feet := BAR_Y + BAR_H
	_runner(_gf, 4, bf_x - GAP, feet, k, ox, oy)
	_runner(_bf, 0, bf_x, feet, k, ox, oy)


func _runner(tex: Texture2D, phase: int, cx: float, feet: float, k: float, ox: float, oy: float) -> void:
	var cw := tex.get_width() / float(FRAMES)
	var ch := float(tex.get_height())
	var f := (int(_t * FPS) + phase) % FRAMES
	var dw := cw * CHAR_SCALE
	var dh := ch * CHAR_SCALE
	var dst := Rect2(ox + (cx - dw * 0.5) * k, oy + (feet - dh) * k, dw * k, dh * k)
	draw_texture_rect_region(tex, dst, Rect2(f * cw, 0.0, cw, ch))
