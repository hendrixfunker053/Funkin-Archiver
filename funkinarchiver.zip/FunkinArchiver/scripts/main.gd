extends Control
## Funkin' Archiver - explorador de archivos tipo ZArchiver con estética Funkin' Backstage.

const VIEW_NAMES := ["Detallado", "Compacto", "Cuadricula"]
const GRID_COLS := 3
const LIST_BOTTOM_PAD := 220.0
const MUSIC_DIR := "user://music"
const MUSIC_INDEX := "user://music.json"
const MUSIC_EXT := ["ogg", "mp3", "wav"]
const SETTINGS_PATH := "user://settings.cfg"
const LOG_PATH := "user://archiver.log"
const TOOLBAR_COLORS := [
	["Rosa", Color("d81b60")], ["Morado", Color("7e57c2")], ["Azul", Color("1e88e5")],
	["Verde", Color("2e7d32")], ["Naranja", Color("ef6c00")], ["Oscuro", Color("2a2430")],
]
const FOLDER_COLORS := [
	["Verde", Color("43a047")], ["Amarillo", Color("ffd54f")], ["Azul", Color("6ec6ff")],
	["Rosa", Color("ff7b9c")], ["Lila", Color("8b8fbf")], ["Blanco", Color("f5f2ea")],
]
const LONG_PRESS := 0.5
const TAP_SLOP := 24.0

# ---------- estado ----------
var root_path: String = ""
var cwd: String = ""
var entries: Array = []
var selected: Dictionary = {}
var selection_mode: bool = false
var clipboard: Array = []
var clipboard_cut: bool = false
var sort_mode: int = 0 # 0 nombre, 1 tamaño, 2 fecha, 3 tipo
var sort_desc: bool = false
var view_mode: int = 0 # 0 detallado, 1 compacto, 2 cuadricula
var show_hidden: bool = false
var sfx_on: bool = true
var music_on: bool = true
var query: String = ""

# ---------- nodos ----------
var bg: TextureRect
var bg_tween: Tween
var scroll: ScrollContainer
var list_host: Control
var search_edit: LineEdit
var info_label: Label
var bottom_panel: PanelContainer
var sel_bar: HBoxContainer
var paste_bar: HBoxContainer
var paste_label: Label
var drawer: Panel
var drawer_dim: ColorRect
var drawer_items: VBoxContainer
var drawer_open: bool = false
var play_ico: Ico
var mute_ico: Ico
var modal_layer: Control
var progress_layer: Control
var progress_bar: LoadingBar
var progress_label: Label
var load_layer: Control
var load_bar: LoadingBar
var load_label: Label
var _listing_busy: bool = false
var _details_n: int = 0
var toast_panel: PanelContainer
var toast_label: Label
var toast_tween: Tween
var lp_timer: Timer
var ambience: AudioStreamPlayer
var sfx: AudioStreamPlayer
var sounds: Dictionary = {}

var _press_pos: Vector2 = Vector2.ZERO
var _press_entry: Dictionary = {}
var _long_fired: bool = false
var _thread: Thread

# ---------- nuevo ----------
var toolbar_idx: int = 0
var folder_idx: int = 5
var fab_on: bool = true
var bg_on: bool = true
var loading: bool = false
var view_arr: Array = []
var active_rows: Dictionary = {} # indice -> fila visible (lista virtual)
var index_of: Dictionary = {}
var entry_by_path: Dictionary = {}
var empty_node: Control
var view_layer: Control
var dual_tab: bool = true
var cur_tab: int = 0
var tab_cwd: Array = ["", ""]
var tab_scroll: Array = [0, 0]
var pane_clip: Control
var peek_host: Control
var dots: Control
var _drag_active: bool = false
var _drag_busy: bool = false
var _drag_frac: float = 0.0
var _drag_scroll_v: int = 0
var _drag_tw: Tween
const PANE_GAP := 28.0
const TEXT_EXT := ["txt", "md", "json", "lua", "hx", "hscript", "xml", "ini", "cfg", "log", "csv", "yml", "yaml", "html", "css", "js", "py", "gd", "tscn", "tres", "godot", "properties", "mcmeta", "lang", "toml", "sh", "bat", "java", "kt", "c", "cpp", "h", "frag", "vert", "glsl"]
var aq: Array = []
var aq_i: int = 0
var player_open: bool = false
var _zb_path: String = ""
var _zb_files: PackedStringArray = PackedStringArray()
var thumb_cache: Dictionary = {}
var _thumb_queue: Array = []
var _thumb_pending: Dictionary = {}
var _thumb_thread: Thread
var main_margin: MarginContainer
var _pending_scroll: int = 0
var _swipe_start: Vector2 = Vector2.ZERO
var _swipe_active: bool = false
var sb_compact: StyleBoxFlat
var sb_compact_sel: StyleBoxFlat
var _list_gen: int = 0
var _list_threads: Array = []
var _last_back_ms: int = 0
var playlist: Array = []
var cur_track: int = -1 # -1 = predeterminada, -2 = archivo suelto, >=0 = mi musica
var pick_music: bool = false
var font_scale: int = 100
var file_info_scale: int = 100
var file_row_scale: int = 100
var default_stream: AudioStream
var fab: Button
var fab_sb: StyleBoxFlat
var now_label: Label
var sb_card: StyleBoxFlat
var sb_card_sel: StyleBoxFlat
var crumb_scroll: ScrollContainer
var crumbs: HBoxContainer


# =====================================================================
# Inicio
# =====================================================================

func _style_scrollbar(sc: ScrollContainer, width: int = 22) -> void:
	# Barras gruesas y contrastadas: visibles también en pantallas táctiles.
	var bar: VScrollBar = sc.get_v_scroll_bar()
	bar.custom_minimum_size.x = width
	bar.add_theme_constant_override("scrollbar_size", width)
	bar.add_theme_constant_override("minimum_grabber_size", 48)
	var track := StyleBoxFlat.new()
	track.bg_color = Color("241b32")
	track.set_corner_radius_all(10)
	var grab := StyleBoxFlat.new()
	grab.bg_color = Color("f4cf45")
	grab.set_corner_radius_all(10)
	grab.content_margin_left = 3
	grab.content_margin_right = 3
	var hot := StyleBoxFlat.new()
	hot.bg_color = Color("ffe477")
	hot.set_corner_radius_all(10)
	bar.add_theme_stylebox_override("scroll", track)
	bar.add_theme_stylebox_override("grabber", grab)
	bar.add_theme_stylebox_override("grabber_highlight", hot)
	bar.add_theme_stylebox_override("grabber_pressed", hot)
	bar.visible = true


func _ready() -> void:
	theme = BSkin.make_theme()
	root_path = _default_root()
	tab_cwd = [root_path, root_path]
	_clean_tmp()
	_load_settings()
	_load_playlist()
	_load_audio()
	_apply_orientation()
	_build_ui()
	get_viewport().size_changed.connect(_on_resized)
	if OS.get_name() == "Android":
		OS.request_permissions()
	navigate(root_path)
	call_deferred("_resume_saved_music")


func _default_root() -> String:
	if OS.get_name() == "Android":
		return "/storage/emulated/0"
	var home := OS.get_environment("HOME")
	if home == "":
		home = OS.get_environment("USERPROFILE").replace("\\", "/")
	if home == "":
		home = ProjectSettings.globalize_path("user://")
	return home


func _exit_tree() -> void:
	if _thread != null and _thread.is_started():
		_thread.wait_to_finish()
	for t in _list_threads:
		if t.is_started():
			t.wait_to_finish()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_go_back(true)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		_go_back(false)


func _apply_orientation() -> void:
	# Misma escala fisica en vertical y apaisado: el lado corto siempre mide 1080.
	var win := DisplayServer.window_get_size()
	if win.x <= 0 or win.y <= 0:
		return
	var want := Vector2i(2400, 1080) if win.x > win.y else Vector2i(1080, 2400)
	var w := get_window()
	if w.content_scale_size != want:
		w.content_scale_size = want


func _on_resized() -> void:
	_apply_orientation()
	if main_margin != null:
		main_margin.add_theme_constant_override("margin_top", int(_safe_top()) + 20)
		main_margin.add_theme_constant_override("margin_bottom", int(_safe_bottom()) + 24)


func _update_tabs() -> void:
	if dots == null:
		return
	dots.visible = dual_tab
	dots.queue_redraw()


func _draw_dots() -> void:
	var c := Vector2(dots.size.x * 0.5, dots.size.y * 0.5)
	for i in 2:
		var strength: float = (1.0 - _drag_frac) if i == cur_tab else _drag_frac
		var r := lerpf(8.0, 12.0, strength)
		var col: Color = BSkin.LILAC_DARK.lerp(BSkin.YELLOW, strength)
		dots.draw_circle(Vector2(c.x + (i - 0.5) * 48.0, c.y), r, col)
		dots.draw_arc(Vector2(c.x + (i - 0.5) * 48.0, c.y), r, 0.0, TAU, 24, BSkin.OFFWHITE, 2.0)


func _switch_tab(idx: int, animate: bool = true) -> void:
	if not dual_tab or idx == cur_tab or idx < 0 or idx > 1:
		return
	tab_scroll[cur_tab] = scroll.scroll_vertical
	tab_cwd[cur_tab] = cwd
	cur_tab = idx
	_sfx("crispy")
	var target: String = tab_cwd[idx]
	if target == "" or not DirAccess.dir_exists_absolute(target):
		target = root_path
	navigate(target)
	if cwd == target:
		_pending_scroll = int(tab_scroll[idx])
	if animate:
		scroll.modulate.a = 0.3
		create_tween().tween_property(scroll, "modulate:a", 1.0, 0.2)
	_update_tabs()


# ---------- Deslizar entre las 2 pestanas: se ven las dos mientras arrastras ----------

func _input(event: InputEvent) -> void:
	if not dual_tab or selection_mode or modal_layer != null or drawer_open \
			or view_layer != null or progress_layer != null:
		if _drag_active and not _drag_busy:
			_cancel_drag()
		_swipe_active = false
		return
	if _drag_busy:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			_swipe_active = pane_clip != null and pane_clip.get_global_rect().has_point(event.global_position)
			_swipe_start = event.global_position
		elif _swipe_active:
			_swipe_active = false
			if _drag_active:
				_finish_drag(event.global_position.x - _swipe_start.x)
	elif event is InputEventMouseMotion and _swipe_active:
		var d: Vector2 = event.global_position - _swipe_start
		if not _drag_active:
			var dir_ok: bool = (d.x < 0.0) if cur_tab == 0 else (d.x > 0.0)
			if dir_ok and absf(d.x) > 28.0 and absf(d.x) > absf(d.y) * 1.5:
				_begin_drag()
		if _drag_active:
			_update_drag(d.x)
			get_viewport().set_input_as_handled()


func _begin_drag() -> void:
	_drag_active = true
	_drag_frac = 0.0
	_drag_scroll_v = scroll.scroll_vertical
	# Cancela el toque / pulsacion larga de la fila sobre la que empezo el gesto.
	lp_timer.stop()
	_press_entry = {}
	_build_peek(1 - cur_tab)


func _pane_w() -> float:
	return pane_clip.size.x + PANE_GAP


func _update_drag(raw_dx: float) -> void:
	var w := _pane_w()
	var dx: float = clampf(raw_dx, -w, 0.0) if cur_tab == 0 else clampf(raw_dx, 0.0, w)
	scroll.scroll_vertical = _drag_scroll_v
	scroll.position.x = dx
	if peek_host != null:
		peek_host.position.x = dx + (w if cur_tab == 0 else -w)
	_drag_frac = absf(dx) / w
	dots.queue_redraw()


func _finish_drag(raw_dx: float) -> void:
	var w := _pane_w()
	var dx: float = clampf(raw_dx, -w, 0.0) if cur_tab == 0 else clampf(raw_dx, 0.0, w)
	var commit: bool = absf(dx) > w * 0.3
	var end_x: float = 0.0
	if commit:
		end_x = -w if cur_tab == 0 else w
	_drag_busy = true
	if _drag_tw != null:
		_drag_tw.kill()
	_drag_tw = create_tween().set_parallel(true).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	_drag_tw.tween_property(scroll, "position:x", end_x, 0.18)
	if peek_host != null:
		_drag_tw.tween_property(peek_host, "position:x", end_x + (w if cur_tab == 0 else -w), 0.18)
	_drag_tw.tween_method(func(v: float):
		_drag_frac = v
		dots.queue_redraw(), _drag_frac, 1.0 if commit else 0.0, 0.18)
	_drag_tw.chain().tween_callback(_drag_done.bind(commit))


func _drag_done(commit: bool) -> void:
	_drag_busy = false
	_drag_active = false
	scroll.position.x = 0.0
	_drag_frac = 0.0
	if commit:
		# El peek se queda tapando la lista hasta que la nueva carpeta tenga filas.
		_switch_tab(1 - cur_tab, false)
		get_tree().create_timer(0.8).timeout.connect(_free_peek)
	else:
		_free_peek()
	dots.queue_redraw()


func _cancel_drag() -> void:
	_drag_active = false
	_swipe_active = false
	_drag_frac = 0.0
	scroll.position.x = 0.0
	_free_peek()
	if dots != null:
		dots.queue_redraw()


func _free_peek() -> void:
	if peek_host != null:
		peek_host.queue_free()
		peek_host = null


func _build_peek(idx: int) -> void:
	## Dibuja la otra pestana (solo las filas visibles) al lado de la actual.
	_free_peek()
	var p: String = String(tab_cwd[idx])
	if p == "" or not DirAccess.dir_exists_absolute(p):
		p = root_path
	peek_host = Control.new()
	peek_host.mouse_filter = Control.MOUSE_FILTER_IGNORE
	peek_host.size = pane_clip.size
	pane_clip.add_child(peek_host)
	var w := _pane_w()
	peek_host.position.x = w if cur_tab == 0 else -w
	var res: Array = FsOps.list_names(p, show_hidden)
	FsOps.sort_default(res)
	var m := _metrics()
	var cols: int = m.cols
	var stride: float = m.ch + m.gap
	var top := float(tab_scroll[idx])
	var first := maxi(0, int(floor(top / stride))) * cols
	var last := mini(res.size(), (int(floor((top + pane_clip.size.y) / stride)) + 1) * cols)
	if res.is_empty():
		var es := _empty_state()
		es.position = Vector2.ZERO
		es.size = Vector2(pane_clip.size.x, 700.0)
		es.mouse_filter = Control.MOUSE_FILTER_IGNORE
		peek_host.add_child(es)
		return
	for i in range(first, last):
		var e: Dictionary = res[i]
		var dd: Array = FsOps.details(e.path, e.is_dir, show_hidden)
		e["size"] = dd[0]
		e["mtime"] = dd[1]
		e["count"] = dd[2]
		e["ok"] = true
		var row := _make_row(e)
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.position = Vector2((i % cols) * (m.cw + m.gap), floorf(i / float(cols)) * stride - top)
		row.size = Vector2(m.cw, m.ch)
		peek_host.add_child(row)


func _toggle_dual() -> void:
	dual_tab = not dual_tab
	if not dual_tab and cur_tab != 0:
		_switch_tab_force_first()
	_save_settings()
	_update_tabs()
	_ui_menu()


func _switch_tab_force_first() -> void:
	cur_tab = 0
	tab_cwd[0] = cwd


func _is_top(p: String) -> bool:
	if p == root_path or p == "/":
		return true
	return p.begins_with("/storage/") and p.count("/") == 2


func _go_back(quit_at_root: bool) -> void:
	if progress_layer != null:
		return
	if view_layer != null:
		_close_view_popup()
		return
	if modal_layer != null:
		_close_modal()
		return
	if drawer_open:
		_toggle_drawer(false)
		return
	if pick_music:
		pick_music = false
		_toast("Importar cancelado")
		return
	if selection_mode:
		_clear_selection()
		return
	if search_edit.visible:
		_toggle_search()
		return
	if not _is_top(cwd) and cwd.get_base_dir() != cwd:
		navigate(cwd.get_base_dir())
	elif quit_at_root:
		var now := Time.get_ticks_msec()
		if now - _last_back_ms < 2000:
			get_tree().quit()
		else:
			_last_back_ms = now
			_toast("Pulse atras para salir")


# =====================================================================
# Audio
# =====================================================================

func _load_audio() -> void:
	ambience = AudioStreamPlayer.new()
	var st: AudioStream = load("res://assets/sounds/mod-menu-ambience.ogg")
	if st is AudioStreamOggVorbis:
		(st as AudioStreamOggVorbis).loop = true
	default_stream = st
	ambience.stream = st
	ambience.volume_db = -12.0
	ambience.finished.connect(_on_music_finished)
	var bi := AudioServer.get_bus_index("Viz")
	if bi == -1:
		AudioServer.add_bus()
		bi = AudioServer.bus_count - 1
		AudioServer.set_bus_name(bi, "Viz")
		AudioServer.add_bus_effect(bi, AudioEffectSpectrumAnalyzer.new())
	ambience.bus = "Viz"
	add_child(ambience)
	ambience.play()
	sfx = AudioStreamPlayer.new()
	sfx.volume_db = -4.0
	add_child(sfx)
	for n in ["crispy", "smoke-cloud", "600_beep2", "600_beep5", "spark-1", "spark-3", "electrocution"]:
		sounds[n] = load("res://assets/sounds/%s.ogg" % n)


func spectrum() -> AudioEffectSpectrumAnalyzerInstance:
	var bi := AudioServer.get_bus_index("Viz")
	if bi == -1:
		return null
	return AudioServer.get_bus_effect_instance(bi, 0) as AudioEffectSpectrumAnalyzerInstance


func _sfx(sound_name: String) -> void:
	if sfx_on and sounds.has(sound_name):
		sfx.stream = sounds[sound_name]
		sfx.play()


func _toggle_music() -> void:
	music_on = not music_on
	ambience.stream_paused = not music_on
	if play_ico:
		play_ico.set_kind("pause" if music_on else "play")


func _toggle_sfx() -> void:
	sfx_on = not sfx_on
	_save_settings()
	if mute_ico:
		mute_ico.set_kind("sound" if sfx_on else "mute")
	_build_drawer_items()


# =====================================================================
# Construcción de la interfaz
# =====================================================================

func _safe_top() -> float:
	if OS.get_name() != "Android":
		return 0.0
	var safe := DisplayServer.get_display_safe_area()
	var win := DisplayServer.window_get_size()
	if win.y <= 0:
		return 0.0
	return safe.position.y * (get_viewport_rect().size.y / float(win.y))


func _safe_bottom() -> float:
	if OS.get_name() != "Android":
		return 0.0
	var safe := DisplayServer.get_display_safe_area()
	var win := DisplayServer.window_get_size()
	if win.y <= 0:
		return 0.0
	var gap := float(win.y) - float(safe.position.y + safe.size.y)
	return maxf(gap, 0.0) * (get_viewport_rect().size.y / float(win.y))


func _btn(text: String, cb: Callable, min_h: float = 110.0) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(0, min_h)
	b.pressed.connect(func():
		_sfx("crispy")
		cb.call())
	return b


func _icon_btn(kind: String, cb: Callable, size_px: float = 110.0) -> Button:
	var b := Button.new()
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(size_px, size_px)
	var ic := Ico.new(kind, BSkin.OFFWHITE, 10.0)
	ic.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, int(size_px * 0.24))
	b.add_child(ic)
	b.pressed.connect(func():
		_sfx("crispy")
		cb.call())
	return b


func _ignore_mouse(n: Node) -> void:
	if n is Control:
		(n as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
	for c in n.get_children():
		_ignore_mouse(c)


func _build_ui() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	sb_card = BSkin.box(BSkin.PANEL, BSkin.OFFWHITE, 5, 22, 16)
	sb_card_sel = BSkin.box(BSkin.YELLOW, BSkin.OFFWHITE, 5, 22, 16)
	sb_compact = BSkin.box(BSkin.PANEL, BSkin.OFFWHITE, 4, 18, 8)
	sb_compact_sel = BSkin.box(BSkin.YELLOW, BSkin.OFFWHITE, 4, 18, 8)

	# Fondo estatico
	bg = TextureRect.new()
	bg.texture = load("res://assets/images/bg.png")
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.visible = bg_on
	add_child(bg)
	_layout_bg()
	get_viewport().size_changed.connect(_layout_bg)

	var dim := ColorRect.new()
	dim.color = Color(0.08, 0.06, 0.1, 0.3)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(dim)

	# Columna principal
	var margin := MarginContainer.new()
	main_margin = margin
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_top", int(_safe_top()) + 20)
	margin.add_theme_constant_override("margin_bottom", int(_safe_bottom()) + 24)
	margin.add_theme_constant_override("margin_left", 28)
	margin.add_theme_constant_override("margin_right", 28)
	add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 16)
	margin.add_child(col)

	# --- Barra superior ---
	var top := PanelContainer.new()
	top.add_theme_stylebox_override("panel", BSkin.box(BSkin.DARK, BSkin.OFFWHITE, 5, 26, 14))
	col.add_child(top)
	var th := HBoxContainer.new()
	th.add_theme_constant_override("separation", 12)
	top.add_child(th)
	th.add_child(_icon_btn("menu", _toggle_drawer.bind(true), 100))
	var title := Label.new()
	title.text = "Funkin' Archiver"
	title.add_theme_font_override("font", BSkin.font_title)
	title.add_theme_font_size_override("font_size", 52)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.clip_text = true
	th.add_child(title)
	th.add_child(_icon_btn("search", _toggle_search, 100))
	th.add_child(_icon_btn("viewmenu", _view_popup, 100))

	# --- Ruta ---
	var path_panel := PanelContainer.new()
	path_panel.add_theme_stylebox_override("panel", BSkin.box(BSkin.DARK, BSkin.OFFWHITE, 5, 22, 10))
	col.add_child(path_panel)
	var ph := HBoxContainer.new()
	ph.add_theme_constant_override("separation", 10)
	path_panel.add_child(ph)
	ph.add_child(_icon_btn("up", _go_back.bind(false), 86))
	crumb_scroll = ScrollContainer.new()
	crumb_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	crumb_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	crumb_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	crumb_scroll.custom_minimum_size = Vector2(0, 86)
	ph.add_child(crumb_scroll)
	crumbs = HBoxContainer.new()
	crumbs.add_theme_constant_override("separation", 6)
	crumb_scroll.add_child(crumbs)

	# --- Buscador ---
	search_edit = LineEdit.new()
	search_edit.placeholder_text = "Buscar en esta carpeta"
	search_edit.clear_button_enabled = true
	search_edit.visible = false
	search_edit.text_changed.connect(func(t: String):
		query = t.strip_edges().to_lower()
		_apply_and_rebuild())
	col.add_child(search_edit)

	# --- Info ---
	info_label = Label.new()
	info_label.add_theme_font_size_override("font_size", _scaled_font(32))
	info_label.add_theme_color_override("font_color", BSkin.LILAC_TEXT)
	info_label.clip_text = true
	col.add_child(info_label)

	# --- Lista ---
	pane_clip = Control.new()
	pane_clip.size_flags_vertical = Control.SIZE_EXPAND_FILL
	pane_clip.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pane_clip.clip_contents = true
	pane_clip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(pane_clip)
	scroll = ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_ALWAYS
	_style_scrollbar(scroll, 24)
	pane_clip.add_child(scroll)
	dots = Control.new()
	dots.custom_minimum_size = Vector2(0, 30)
	dots.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dots.visible = dual_tab
	dots.draw.connect(_draw_dots)
	col.add_child(dots)
	list_host = Control.new()
	list_host.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_host.mouse_filter = Control.MOUSE_FILTER_PASS
	scroll.add_child(list_host)
	list_host.resized.connect(_layout_virtual)
	scroll.resized.connect(_refresh_visible)
	scroll.get_v_scroll_bar().value_changed.connect(_on_scroll_changed)

	# --- Barra inferior (selección / pegar) ---
	bottom_panel = PanelContainer.new()
	bottom_panel.add_theme_stylebox_override("panel", BSkin.box(BSkin.DARK, BSkin.OFFWHITE, 5, 26, 14))
	bottom_panel.visible = false
	col.add_child(bottom_panel)
	var bv := VBoxContainer.new()
	bottom_panel.add_child(bv)
	sel_bar = HBoxContainer.new()
	sel_bar.add_theme_constant_override("separation", 10)
	bv.add_child(sel_bar)
	for spec in [["Copiar", _sel_copy], ["Cortar", _sel_cut], ["Borrar", _sel_delete], ["ZIP", _sel_zip], ["Mas", _sel_more]]:
		var b := _btn(spec[0], spec[1], 100)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 38)
		sel_bar.add_child(b)
	paste_bar = HBoxContainer.new()
	paste_bar.add_theme_constant_override("separation", 10)
	bv.add_child(paste_bar)
	paste_label = Label.new()
	paste_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	paste_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	paste_label.clip_text = true
	paste_bar.add_child(paste_label)
	var paste_btn := _btn("Pegar aqui", _paste, 100)
	paste_btn.add_theme_stylebox_override("normal", BSkin.box(BSkin.YELLOW))
	paste_btn.add_theme_color_override("font_color", BSkin.DARK)
	paste_bar.add_child(paste_btn)
	paste_bar.add_child(_icon_btn("close", _clear_clipboard, 100))

	fab_sb = BSkin.box(BSkin.YELLOW, BSkin.OFFWHITE, 6, 100, 0)
	fab_sb.shadow_color = Color(0, 0, 0, 0.45)
	fab_sb.shadow_size = 14
	fab_sb.shadow_offset = Vector2(0, 6)
	fab = Button.new()
	fab.focus_mode = Control.FOCUS_NONE
	for stn in ["normal", "hover", "pressed"]:
		fab.add_theme_stylebox_override(stn, fab_sb)
	fab.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	fab.offset_left = -250
	fab.offset_right = -70
	fab.offset_top = -(250 + _safe_bottom())
	fab.offset_bottom = -(70 + _safe_bottom())
	var fic := Ico.new("plus", BSkin.DARK, 10.0)
	fic.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 50)
	fab.add_child(fic)
	fab.pressed.connect(func():
		_sfx("crispy")
		_new_menu())
	fab.visible = fab_on
	add_child(fab)

	lp_timer = Timer.new()
	lp_timer.one_shot = true
	lp_timer.timeout.connect(_on_long_press)
	add_child(lp_timer)

	_build_drawer()
	_build_toast()


func _clear_clipboard() -> void:
	clipboard.clear()
	_update_bars()


func _layout_bg() -> void:
	if bg == null:
		return
	var vs := get_viewport_rect().size
	var h := vs.y
	var w := h * 2560.0 / 1080.0
	bg.size = Vector2(w, h)
	bg.position = Vector2.ZERO
	if bg_tween:
		bg_tween.kill()
	# El fondo permanece fijo; solo se adapta al tamano de pantalla.


# =====================================================================
# Menú lateral
# =====================================================================

func _build_drawer() -> void:
	drawer_dim = ColorRect.new()
	drawer_dim.color = Color(0, 0, 0, 0)
	drawer_dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	drawer_dim.mouse_filter = Control.MOUSE_FILTER_STOP
	drawer_dim.visible = false
	drawer_dim.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.pressed:
			_toggle_drawer(false))
	add_child(drawer_dim)

	drawer = Panel.new()
	var sb := BSkin.box(BSkin.DARK, BSkin.OFFWHITE, 0, 0, 0)
	sb.border_width_right = 8
	drawer.add_theme_stylebox_override("panel", sb)
	drawer.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	drawer.offset_left = -830
	drawer.offset_right = -30
	drawer.visible = false
	add_child(drawer)

	var m := MarginContainer.new()
	m.set_anchors_preset(Control.PRESET_FULL_RECT)
	m.add_theme_constant_override("margin_top", int(_safe_top()) + 30)
	m.add_theme_constant_override("margin_bottom", int(_safe_bottom()) + 30)
	m.add_theme_constant_override("margin_left", 30)
	m.add_theme_constant_override("margin_right", 38)
	drawer.add_child(m)
	var v := VBoxContainer.new()
	v.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 12)
	m.add_child(v)

	# Cabecera
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 22)
	v.add_child(head)
	var av := TextureRect.new()
	av.texture = load("res://assets/images/base-icon.png")
	av.custom_minimum_size = Vector2(120, 120)
	av.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	av.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	head.add_child(av)
	var hl := Label.new()
	hl.text = "Funkin' Archiver"
	hl.add_theme_font_override("font", BSkin.font_title)
	hl.add_theme_font_size_override("font_size", 50)
	hl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	head.add_child(hl)

	var dsc := ScrollContainer.new()
	dsc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	dsc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	dsc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_ALWAYS
	_style_scrollbar(dsc, 24)
	v.add_child(dsc)
	drawer_items = VBoxContainer.new()
	drawer_items.add_theme_constant_override("separation", 10)
	drawer_items.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	dsc.add_child(drawer_items)

	# Reproductor "Now Playing"
	var np := PanelContainer.new()
	np.add_theme_stylebox_override("panel", BSkin.box(BSkin.LILAC_DARK, BSkin.OFFWHITE, 5, 20, 16))
	v.add_child(np)
	var npl := Label.new()
	npl.text = "Now Playing: Mod Menu Ambience"
	npl.add_theme_font_size_override("font_size", 34)
	npl.clip_text = true
	now_label = npl
	np.add_child(npl)
	var dviz := MusicViz.new(96.0)
	dviz.analyzer = spectrum()
	v.add_child(dviz)

	var ctrl := HBoxContainer.new()
	ctrl.add_theme_constant_override("separation", 12)
	v.add_child(ctrl)
	var mute_btn := _icon_btn("sound", _toggle_sfx, 110)
	mute_ico = mute_btn.get_child(0) as Ico
	mute_ico.set_kind("sound" if sfx_on else "mute")
	ctrl.add_child(mute_btn)
	var prev_btn := _icon_btn("prev", _prev_track, 110)
	prev_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ctrl.add_child(prev_btn)
	var play_btn := _icon_btn("pause", _toggle_music, 110)
	play_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	play_ico = play_btn.get_child(0) as Ico
	ctrl.add_child(play_btn)
	var next_btn := _icon_btn("next", _next_track, 110)
	next_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ctrl.add_child(next_btn)


func _drawer_item(label: String, kind: String, active: bool, cb: Callable) -> Button:
	var b := Button.new()
	b.text = label
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(0, 118)
	b.clip_text = true
	var n := BSkin.box(BSkin.YELLOW if active else BSkin.DARK, BSkin.YELLOW if active else BSkin.DARK, 4, 16, 18)
	n.content_margin_left = 150
	var hv := BSkin.box(BSkin.LILAC_DARK, BSkin.LILAC_DARK, 4, 16, 18)
	hv.content_margin_left = 150
	var pr: StyleBoxFlat = n.duplicate()
	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", hv if not active else n)
	b.add_theme_stylebox_override("pressed", pr)
	if active:
		for k in ["font_color", "font_hover_color", "font_pressed_color"]:
			b.add_theme_color_override(k, BSkin.DARK)
	var ic := Ico.new(kind, BSkin.DARK if active else BSkin.OFFWHITE, 10.0)
	ic.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	ic.offset_left = 34
	ic.offset_right = 110
	ic.offset_top = 22
	ic.offset_bottom = -22
	b.add_child(ic)
	b.pressed.connect(func():
		_sfx("crispy")
		cb.call())
	return b


func _drawer_then(cb: Callable) -> void:
	_toggle_drawer(false)
	cb.call()


func _build_drawer_items() -> void:
	if drawer_items == null:
		return
	for c in drawer_items.get_children():
		drawer_items.remove_child(c)
		c.queue_free()
	var places: Array = _places()
	var best := -1
	var best_len := -1
	for i in places.size():
		var p: String = places[i][2]
		if FsOps.is_inside(cwd, p) and p.length() > best_len:
			best = i
			best_len = p.length()
	for i in places.size():
		var dest: String = places[i][2]
		drawer_items.add_child(_drawer_item(places[i][0], places[i][1], i == best, _on_place.bind(dest)))

	var sep := ColorRect.new()
	sep.color = BSkin.LILAC_DARK
	sep.custom_minimum_size = Vector2(0, 4)
	drawer_items.add_child(sep)

	drawer_items.add_child(_drawer_item("Mi musica (%d)" % playlist.size(), "audio", false, _drawer_then.bind(_music_menu)))
	drawer_items.add_child(_drawer_item("Importar musica", "plus", false, _import_hint))
	drawer_items.add_child(_drawer_item("Nuevo", "plus", false, _drawer_then.bind(_new_menu)))
	drawer_items.add_child(_drawer_item("Actualizar", "up", false, _drawer_then.bind(refresh)))
	drawer_items.add_child(_drawer_item("Ir a ruta...", "folder", false, _drawer_then.bind(_goto_path_dialog)))
	drawer_items.add_child(_drawer_item("Ocultos: " + ("Si" if show_hidden else "No"), "search", false, _toggle_hidden))
	drawer_items.add_child(_drawer_item("Sonidos: " + ("Si" if sfx_on else "No"), "sound" if sfx_on else "mute", false, _toggle_sfx))
	drawer_items.add_child(_drawer_item("Ajustes", "menu", false, _drawer_then.bind(_settings_menu)))
	if OS.get_name() == "Android":
		drawer_items.add_child(_drawer_item("Permisos de archivos", "check", false, _ask_permissions))
		drawer_items.add_child(_drawer_item("Shizuku / Android data", "phone", false, _drawer_then.bind(_shizuku_info)))


func _on_place(dest: String) -> void:
	_toggle_drawer(false)
	navigate(dest)


func _goto_path_dialog() -> void:
	_modal_input("Ir a ruta", cwd, "Ir", _goto_path)


func _goto_path(t: String) -> void:
	var p := t.strip_edges()
	if p == "":
		return
	if not p.begins_with("/"):
		p = FsOps.join(cwd, p)
	navigate(p)


func _is_android_private(p: String) -> bool:
	return OS.get_name() == "Android" and (p.contains("/Android/data") or p.contains("/Android/obb"))


func _toggle_hidden() -> void:
	show_hidden = not show_hidden
	_save_settings()
	_build_drawer_items()
	refresh()


func _ask_permissions() -> void:
	OS.request_permissions()


func _toggle_drawer(open: bool) -> void:
	if open == drawer_open:
		return
	drawer_open = open
	if open:
		_build_drawer_items()
		drawer.visible = true
		drawer_dim.visible = true
	var tw := create_tween().set_parallel(true).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tw.tween_property(drawer, "offset_left", 0.0 if open else -830.0, 0.25)
	tw.tween_property(drawer, "offset_right", 800.0 if open else -30.0, 0.25)
	tw.tween_property(drawer_dim, "color:a", 0.55 if open else 0.0, 0.25)
	if not open:
		tw.chain().tween_callback(func():
			if not drawer_open:
				drawer.visible = false
				drawer_dim.visible = false)


# =====================================================================
# Navegación y lista
# =====================================================================

func navigate(path: String) -> void:
	var p := path.simplify_path()
	if p.length() > 1 and p.ends_with("/") and not p.ends_with(":/"):
		p = p.rstrip("/")
	if not DirAccess.dir_exists_absolute(p):
		_toast("No se puede abrir esa carpeta")
		_sfx("spark-3")
		return
	var d := DirAccess.open(p)
	if d == null:
		_toast("Sin acceso (error %d). Revisa los permisos." % DirAccess.get_open_error())
		_sfx("spark-3")
		return
	cwd = p
	tab_cwd[cur_tab] = p
	_pending_scroll = 0
	_update_tabs()
	selection_mode = false
	selected.clear()
	query = ""
	if search_edit:
		search_edit.text = ""
	refresh()


func refresh() -> void:
	_list_gen += 1
	var gen := _list_gen
	loading = true
	entries = []
	entry_by_path = {}
	_listing_busy = true
	_details_n = 0
	_hide_loading(false)
	get_tree().create_timer(0.35).timeout.connect(_maybe_show_loading.bind(gen))
	_clear_rows()
	_build_crumbs()
	_update_bars()
	var path := cwd
	var hidden := show_hidden
	_log("listando " + path)
	var th := Thread.new()
	_list_threads.append(th)
	th.start(_list_worker.bind(gen, path, hidden, th))


func _list_worker(gen: int, path: String, hidden: bool, th: Thread) -> void:
	# Fase 1: solo nombres (se muestran al instante).
	# Fase 2: tamano, fecha y conteo de carpetas, en lotes pequenos.
	var res: Array = FsOps.list_names(path, hidden)
	FsOps.sort_default(res)
	var work: Array = []
	for e in res:
		work.append([e.path, e.is_dir])
	_names_ready.call_deferred(gen, res)
	var chunk: Array = []
	for w in work:
		if gen != _list_gen:
			break
		var d: Array = FsOps.details(w[0], w[1], hidden)
		chunk.append([w[0], d[0], d[1], d[2]])
		if chunk.size() >= 40:
			_details_chunk.call_deferred(gen, chunk)
			chunk = []
	if not chunk.is_empty() and gen == _list_gen:
		_details_chunk.call_deferred(gen, chunk)
	_details_done.call_deferred(gen, th)


func _names_ready(gen: int, res: Array) -> void:
	if gen != _list_gen:
		return
	_log("listado %d elementos" % res.size())
	if res.is_empty() and _is_android_private(cwd):
		_toast("Android bloquea esta carpeta a las apps (Android 11+). Prueba 'Ir a ruta...' con la carpeta de un paquete.")
	loading = false
	entries = res
	_update_loading()
	entry_by_path = {}
	for e in entries:
		entry_by_path[e.path] = e
	_apply_and_rebuild()
	if _pending_scroll > 0:
		var ps := _pending_scroll
		_pending_scroll = 0
		await get_tree().process_frame
		scroll.scroll_vertical = ps
		_refresh_visible()
	_free_peek()


func _details_chunk(gen: int, chunk: Array) -> void:
	if gen != _list_gen:
		return
	for it in chunk:
		var e: Dictionary = entry_by_path.get(it[0], {})
		if e.is_empty():
			continue
		e["size"] = it[1]
		e["mtime"] = it[2]
		e["count"] = it[3]
		e["ok"] = true
		_rebuild_row(it[0], false, true)
	_details_n += chunk.size()
	_update_loading()
	_refresh_visible()


func _details_done(gen: int, th: Thread) -> void:
	th.wait_to_finish()
	_list_threads.erase(th)
	if gen != _list_gen:
		return
	_listing_busy = false
	_hide_loading()
	if sort_mode == 1 or sort_mode == 2:
		_rebuild_rows(true)
		_update_bars()


func _apply_and_rebuild() -> void:
	_rebuild_rows(false)
	_update_bars()


func _filtered_sorted() -> Array:
	var arr: Array = []
	for e in entries:
		if query == "" or String(e.name).to_lower().contains(query):
			arr.append(e)
	var mode := sort_mode
	var desc := sort_desc
	arr.sort_custom(func(a, b):
		if a.is_dir != b.is_dir:
			return a.is_dir
		var c: int = 0
		if mode == 1:
			c = signi(a.size - b.size)
		elif mode == 2:
			c = signi(a.mtime - b.mtime)
		elif mode == 3:
			c = String(a.name).get_extension().to_lower().naturalnocasecmp_to(String(b.name).get_extension().to_lower())
		if c == 0:
			c = String(a.name).naturalnocasecmp_to(String(b.name))
		if desc:
			c = -c
		return c < 0)
	return arr


func _clear_rows() -> void:
	_free_active()
	if empty_node != null:
		empty_node.queue_free()
		empty_node = null
	view_arr = []
	index_of = {}
	if list_host != null:
		list_host.custom_minimum_size = Vector2.ZERO


func _build_crumbs() -> void:
	for c in crumbs.get_children():
		c.queue_free()
	var parts := cwd.split("/", false)
	var acc := ""
	if cwd.begins_with("/"):
		crumbs.add_child(_crumb("/", "/", parts.is_empty()))
	for i in parts.size():
		if i == 0 and not cwd.begins_with("/"):
			acc = parts[i]
		else:
			acc += "/" + parts[i]
		var target := acc + "/" if acc.ends_with(":") else acc
		crumbs.add_child(_crumb(parts[i], target, i == parts.size() - 1))
	await get_tree().process_frame
	crumb_scroll.scroll_horizontal = int(crumb_scroll.get_h_scroll_bar().max_value)


func _crumb(label: String, target: String, last: bool) -> Button:
	var b := Button.new()
	b.text = label
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(0, 76)
	b.add_theme_font_size_override("font_size", 38)
	b.add_theme_stylebox_override("normal", BSkin.box(BSkin.YELLOW if last else BSkin.LILAC_DARK, BSkin.OFFWHITE, 3, 16, 12))
	b.add_theme_stylebox_override("hover", BSkin.box(BSkin.YELLOW if last else BSkin.LILAC, BSkin.OFFWHITE, 3, 16, 12))
	if last:
		b.add_theme_color_override("font_color", BSkin.DARK)
	b.pressed.connect(func():
		_sfx("crispy")
		if target != cwd:
			navigate(target))
	return b


func _metrics() -> Dictionary:
	var w: float = list_host.size.x
	if w <= 1.0:
		w = maxf(get_viewport_rect().size.x - 56.0, 200.0)
	var row_factor := float(file_row_scale) / 100.0
	if view_mode == 1:
		return {"cols": 1, "cw": w, "ch": 84.0 * row_factor, "gap": 8.0}
	if view_mode == 2:
		var gap := 14.0
		var n_cols := maxi(GRID_COLS, int(w / 340.0))
		var cw := (w - gap * (n_cols - 1)) / float(n_cols)
		return {"cols": n_cols, "cw": cw, "ch": 270.0 * row_factor, "gap": gap}
	return {"cols": 1, "cw": w, "ch": 136.0 * row_factor, "gap": 12.0}


func _drop_row(node: Control) -> void:
	if node.get_parent() != null:
		node.get_parent().remove_child(node)
	node.queue_free()


func _free_active() -> void:
	for idx in active_rows:
		_drop_row(active_rows[idx])
	active_rows = {}


func _layout_virtual() -> void:
	if list_host == null:
		return
	var m := _metrics()
	var cols: int = m.cols
	var rows := ceili(float(view_arr.size()) / float(cols))
	var h: float = rows * (m.ch + m.gap) + LIST_BOTTOM_PAD
	if empty_node != null:
		h = 700.0
		empty_node.size = Vector2(maxf(list_host.size.x, 100.0), 700.0)
	list_host.custom_minimum_size = Vector2(0, h)
	_free_active()
	_refresh_visible()


func _refresh_visible() -> void:
	if list_host == null or scroll == null:
		return
	var m := _metrics()
	var cols: int = m.cols
	var stride: float = m.ch + m.gap
	var n := view_arr.size()
	var top := float(scroll.scroll_vertical)
	var first_row := maxi(0, int(floor(top / stride)) - 2)
	var last_row := int(floor((top + scroll.size.y) / stride)) + 2
	var first := first_row * cols
	var last := mini(n, (last_row + 1) * cols)
	for idx in active_rows.keys():
		if idx < first or idx >= last:
			_drop_row(active_rows[idx])
			active_rows.erase(idx)
	for i in range(first, last):
		if active_rows.has(i):
			continue
		var row := _make_row(view_arr[i])
		row.position = Vector2((i % cols) * (m.cw + m.gap), floorf(i / float(cols)) * stride)
		row.size = Vector2(m.cw, m.ch)
		list_host.add_child(row)
		active_rows[i] = row


func _on_scroll_changed(_v: float) -> void:
	_refresh_visible()


func _rebuild_rows(keep_scroll: bool) -> void:
	var saved: int = scroll.scroll_vertical
	_clear_rows()
	view_arr = _filtered_sorted()
	for i in view_arr.size():
		index_of[view_arr[i].path] = i
	if view_arr.is_empty() and not loading:
		empty_node = _empty_state()
		empty_node.position = Vector2.ZERO
		list_host.add_child(empty_node)
	_layout_virtual()
	if keep_scroll:
		await get_tree().process_frame
		scroll.scroll_vertical = saved
		_refresh_visible()
	else:
		scroll.scroll_vertical = 0


func _empty_state() -> Control:
	var c := VBoxContainer.new()
	c.alignment = BoxContainer.ALIGNMENT_CENTER
	c.custom_minimum_size = Vector2(0, 700)
	var tr := TextureRect.new()
	tr.texture = load("res://assets/images/drop-hover.png")
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tr.custom_minimum_size = Vector2(0, 420)
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.add_child(tr)
	var l := Label.new()
	l.text = "Aqui no hay nada" if query == "" else "Sin resultados"
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_color_override("font_color", BSkin.LILAC_TEXT)
	c.add_child(l)
	return c


func _scaled_font(base_size: int, scale: int = -1) -> int:
	var factor := font_scale if scale < 0 else scale
	return maxi(12, int(round(float(base_size) * float(factor) / 100.0)))


func _make_row(e: Dictionary) -> Control:
	var path: String = e.path
	var is_dir: bool = e.is_dir
	var is_sel := selected.has(path)
	var kind := FsOps.kind_of(path, is_dir)
	var icol: Color = FOLDER_COLORS[folder_idx][1]
	match kind:
		"zip":
			icol = BSkin.YELLOW
		"image":
			icol = BSkin.BLUE
		"audio":
			icol = BSkin.PINK
		"apk":
			icol = BSkin.GREEN
		"file":
			icol = BSkin.LILAC_TEXT
	if is_sel:
		icol = BSkin.DARK
	var txt: Color = BSkin.DARK if is_sel else BSkin.OFFWHITE
	var sub_col: Color = BSkin.DARK if is_sel else BSkin.LILAC_TEXT
	var has_info: bool = e.get("ok", false)

	var left_text := ""
	var cnt: int = e.get("count", -1)
	if is_dir:
		if cnt == 0:
			left_text = "Vacio"
		elif cnt == 1:
			left_text = "1 elemento"
		elif cnt > 1:
			left_text = "%d elementos" % cnt
		else:
			left_text = "Carpeta"
	elif has_info:
		left_text = FsOps.format_size(e.size)
	var date_text := FsOps.format_time(e.mtime) if has_info else ""

	var row := PanelContainer.new()
	row.clip_contents = true
	row.mouse_filter = Control.MOUSE_FILTER_PASS
	row.set_meta("path", path)
	var compact := view_mode == 1
	if compact:
		row.add_theme_stylebox_override("panel", sb_compact_sel if is_sel else sb_compact)
	else:
		row.add_theme_stylebox_override("panel", sb_card_sel if is_sel else sb_card)

	if view_mode == 2:
		var gv := VBoxContainer.new()
		gv.alignment = BoxContainer.ALIGNMENT_CENTER
		gv.add_theme_constant_override("separation", 4)
		row.add_child(gv)
		var gic := _ico_or_thumb(kind, icol, 110.0, path)
		gic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		gv.add_child(gic)
		var gname := Label.new()
		gname.text = e.get("disp", e.name)
		gname.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		gname.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
		gname.max_lines_visible = 2
		gname.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		gname.add_theme_font_size_override("font_size", _scaled_font(28))
		gname.add_theme_color_override("font_color", txt)
		gv.add_child(gname)
		var gsub := Label.new()
		gsub.text = left_text
		gsub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		gsub.clip_text = true
		gsub.add_theme_font_size_override("font_size", _scaled_font(22, file_info_scale))
		gsub.add_theme_color_override("font_color", sub_col)
		gv.add_child(gsub)
		_ignore_mouse(gv)
	elif compact:
		var ch := HBoxContainer.new()
		ch.add_theme_constant_override("separation", 18)
		row.add_child(ch)
		var cic := _ico_or_thumb(kind, icol, 52.0, path)
		cic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		ch.add_child(cic)
		var cname := Label.new()
		cname.text = e.get("disp", e.name)
		cname.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		cname.clip_text = true
		cname.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		cname.add_theme_font_size_override("font_size", 34)
		cname.add_theme_color_override("font_color", txt)
		ch.add_child(cname)
		var cright := Label.new()
		cright.text = left_text
		cright.add_theme_font_size_override("font_size", _scaled_font(24))
		cright.add_theme_color_override("font_color", sub_col)
		ch.add_child(cright)
		if is_sel:
			var cck := Ico.new("check", BSkin.DARK, 44.0)
			cck.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			ch.add_child(cck)
		_ignore_mouse(ch)
	else:
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 22)
		row.add_child(h)
		var ic := _ico_or_thumb(kind, icol, 80.0, path)
		ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		h.add_child(ic)

		var v := VBoxContainer.new()
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		v.alignment = BoxContainer.ALIGNMENT_CENTER
		v.add_theme_constant_override("separation", 0)
		h.add_child(v)
		var name_l := Label.new()
		name_l.text = e.get("disp", e.name)
		name_l.clip_text = true
		name_l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		name_l.add_theme_font_size_override("font_size", 42)
		name_l.add_theme_color_override("font_color", txt)
		v.add_child(name_l)

		var sub := HBoxContainer.new()
		sub.add_theme_constant_override("separation", 12)
		v.add_child(sub)
		var left := Label.new()
		left.text = left_text
		left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		left.clip_text = true
		left.add_theme_font_size_override("font_size", _scaled_font(28))
		left.add_theme_color_override("font_color", sub_col)
		sub.add_child(left)
		var right := Label.new()
		right.text = date_text
		right.add_theme_font_size_override("font_size", _scaled_font(28))
		right.add_theme_color_override("font_color", sub_col)
		sub.add_child(right)

		if is_sel:
			var ck := Ico.new("check", BSkin.DARK, 60.0)
			ck.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			h.add_child(ck)
		_ignore_mouse(h)

	row.gui_input.connect(_on_row_input.bind(e))
	return row


func _rebuild_row(path: String, refresh_now: bool = true, skip_pressed: bool = false) -> void:
	if skip_pressed and _press_entry.get("path", "") == path:
		return
	var idx: int = index_of.get(path, -1)
	if idx >= 0 and active_rows.has(idx):
		_drop_row(active_rows[idx])
		active_rows.erase(idx)
		if refresh_now:
			_refresh_visible()


func _update_bars() -> void:
	sel_bar.visible = selection_mode
	paste_bar.visible = (not selection_mode) and not clipboard.is_empty()
	bottom_panel.visible = sel_bar.visible or paste_bar.visible
	if fab:
		fab.visible = fab_on and not bottom_panel.visible
	if paste_bar.visible:
		var verb := "mover" if clipboard_cut else "copiar"
		paste_label.text = "%d para %s" % [clipboard.size(), verb]
	if selection_mode:
		info_label.text = "%d seleccionado%s" % [selected.size(), "" if selected.size() == 1 else "s"]
	elif loading:
		info_label.text = "Cargando..."
	else:
		var n := view_arr.size()
		info_label.text = "%d elemento%s" % [n, "" if n == 1 else "s"] + (" (filtrado)" if query != "" else "")


# =====================================================================
# Toques y selección
# =====================================================================

func _on_row_input(ev: InputEvent, e: Dictionary) -> void:
	if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
		if ev.pressed:
			_press_pos = ev.global_position
			_press_entry = e
			_long_fired = false
			lp_timer.start(LONG_PRESS)
		else:
			lp_timer.stop()
			if not _long_fired and ev.global_position.distance_to(_press_pos) < TAP_SLOP and _press_entry.get("path", "") == e.path:
				_on_tap(e)
			_press_entry = {}
	elif ev is InputEventMouseMotion and not lp_timer.is_stopped():
		if ev.global_position.distance_to(_press_pos) > TAP_SLOP:
			lp_timer.stop()


func _on_long_press() -> void:
	if _press_entry.is_empty():
		return
	_long_fired = true
	Input.vibrate_handheld(40)
	_sfx("600_beep5")
	selection_mode = true
	_toggle(_press_entry)


func _on_tap(e: Dictionary) -> void:
	if selection_mode:
		_toggle(e)
		return
	_sfx("crispy")
	var path: String = e.path
	var kind := FsOps.kind_of(path, e.is_dir)
	if e.is_dir:
		navigate(path)
	elif kind == "zip":
		_zip_browser(path, "")
	elif kind == "apk":
		_apk_menu(e)
	elif kind == "audio":
		if pick_music:
			pick_music = false
			_import_music([path])
		else:
			_audio_open(path)
	else:
		_file_menu(e)


func _file_menu(e: Dictionary) -> void:
	_menu_modal(String(e.get("disp", e.name)), [
		["Abrir con app", _open_with.bind(String(e.path))],
		["Propiedades", _show_properties.bind(e)],
	])


func _open_with(path: String) -> void:
	## Lanza el archivo con otra app (el selector de Android deja elegir cual).
	if not FileAccess.file_exists(path):
		_toast("No se encuentra el archivo")
		return
	var err: int = OS.shell_open("file://" + path)
	if err != OK:
		_sfx("spark-3")
		_toast("No se pudo abrir con otra app (error %d)" % err)


func _toggle(e: Dictionary) -> void:
	var path: String = e.path
	if selected.has(path):
		selected.erase(path)
	else:
		selected[path] = true
	if selected.is_empty():
		selection_mode = false
	_rebuild_row(path)
	_update_bars()


func _clear_selection() -> void:
	selection_mode = false
	selected.clear()
	_rebuild_rows(true)
	_update_bars()


func _select_all() -> void:
	for e in _filtered_sorted():
		selected[e.path] = true
	selection_mode = not selected.is_empty()
	_rebuild_rows(true)
	_update_bars()


# =====================================================================
# Acciones sobre la selección
# =====================================================================

func _sel_paths() -> Array:
	return selected.keys()


func _sel_copy() -> void:
	clipboard = _sel_paths()
	clipboard_cut = false
	_toast("%d para copiar" % clipboard.size())
	_clear_selection()


func _sel_cut() -> void:
	clipboard = _sel_paths()
	clipboard_cut = true
	_toast("%d para mover" % clipboard.size())
	_clear_selection()


func _sel_delete() -> void:
	var paths := _sel_paths()
	var msg := "Borrar %d elemento%s? No se puede deshacer." % [paths.size(), "" if paths.size() == 1 else "s"]
	_modal("Borrar", _label_body(msg), [
		["Cancelar", Callable(), false],
		["Borrar", _do_delete.bind(paths), true],
	])


func _do_delete(paths: Array) -> void:
	var ops := FsOps.new()
	ops.total = ops.count_files(paths)
	var work := func() -> int:
		var err: int = OK
		for p in paths:
			var r: int = ops.delete_any(p)
			if r != OK:
				err = r
		return err
	_run_job("Borrando...", ops, work, "Listo", "spark-1")


func _sel_zip() -> void:
	var paths := _sel_paths()
	var default_name := "archivo.zip"
	if paths.size() == 1:
		default_name = String(paths[0]).get_file().get_basename() + ".zip"
	_modal_input("Comprimir en ZIP", default_name, "Crear", _do_zip.bind(paths))


func _do_zip(t: String, paths: Array) -> void:
	var zip_name := t.strip_edges()
	if zip_name == "":
		return
	if not zip_name.to_lower().ends_with(".zip"):
		zip_name += ".zip"
	var dst := FsOps.unique_path(FsOps.join(cwd, zip_name))
	var ops := FsOps.new()
	ops.total = ops.count_files(paths, true)
	var work := func() -> int:
		return ops.compress(paths, dst)
	_run_job("Comprimiendo...", ops, work, "ZIP creado: " + dst.get_file(), "smoke-cloud")


func _sel_more() -> void:
	var items: Array = []
	if selected.size() == 1:
		items.append(["Renombrar", _sel_rename])
		var only: String = String(selected.keys()[0])
		if not DirAccess.dir_exists_absolute(only):
			items.append(["Abrir con app", _open_with.bind(only)])
		items.append(["Propiedades", _props_of_selected])
	for p in selected.keys():
		if not DirAccess.dir_exists_absolute(p) and FsOps.ext_of(p) in MUSIC_EXT:
			items.append(["Importar como musica", _import_selected_music])
			break
	items.append(["Seleccionar todo", _select_all])
	items.append(["Cancelar seleccion", _clear_selection])
	_menu_modal("Mas opciones", items)


func _props_of_selected() -> void:
	for e in entries:
		if selected.has(e.path):
			_show_properties(e)
			return


func _sel_rename() -> void:
	var old: String = _sel_paths()[0]
	_modal_input("Renombrar", old.get_file(), "Guardar", _do_rename.bind(old))


func _do_rename(t: String, old: String) -> void:
	var new_name := t.strip_edges()
	if new_name == "" or new_name.contains("/") or new_name.contains("\\"):
		_toast("Nombre no valido")
		return
	var dst := FsOps.join(old.get_base_dir(), new_name)
	if FileAccess.file_exists(dst) or DirAccess.dir_exists_absolute(dst):
		_toast("Ya existe ese nombre")
		return
	var err: int = DirAccess.rename_absolute(old, dst)
	if err != OK:
		_toast("Error: " + error_string(err))
		_sfx("electrocution")
	else:
		_toast("Renombrado")
	_clear_selection()
	refresh()


func _paste() -> void:
	var srcs := clipboard.duplicate()
	var dst := cwd
	var cut := clipboard_cut
	for s in srcs:
		if DirAccess.dir_exists_absolute(s) and FsOps.is_inside(dst, s):
			_toast("No se puede pegar una carpeta dentro de si misma")
			_sfx("spark-3")
			return
	var ops := FsOps.new()
	ops.total = srcs.size() if cut else ops.count_files(srcs)
	clipboard.clear()
	var work := func() -> int:
		var err: int = OK
		for s in srcs:
			var r: int = ops.move_any(s, dst) if cut else ops.copy_any(s, dst)
			if r != OK:
				err = r
		return err
	_run_job("Moviendo..." if cut else "Copiando...", ops, work, "Listo", "smoke-cloud")


# =====================================================================
# Menús: nuevo, ordenar, ZIP, propiedades
# =====================================================================

func _new_menu() -> void:
	_menu_modal("Nuevo", [
		["Carpeta", _new_folder_dialog],
		["Archivo vacio", _new_file_dialog],
	])


func _new_folder_dialog() -> void:
	_modal_input("Nueva carpeta", "Nueva carpeta", "Crear", _create_folder)


func _create_folder(t: String) -> void:
	var n := t.strip_edges()
	if n == "" or n.contains("/"):
		_toast("Nombre no valido")
		return
	var err: int = DirAccess.make_dir_absolute(FsOps.unique_path(FsOps.join(cwd, n)))
	_toast("Carpeta creada" if err == OK else "Error: " + error_string(err))
	refresh()


func _new_file_dialog() -> void:
	_modal_input("Nuevo archivo", "nuevo.txt", "Crear", _create_file)


func _create_file(t: String) -> void:
	var n := t.strip_edges()
	if n == "" or n.contains("/"):
		_toast("Nombre no valido")
		return
	var f := FileAccess.open(FsOps.unique_path(FsOps.join(cwd, n)), FileAccess.WRITE)
	if f == null:
		_toast("Error: " + error_string(FileAccess.get_open_error()))
	else:
		f.close()
		_toast("Archivo creado")
	refresh()


func _view_popup() -> void:
	if view_layer != null:
		_close_view_popup()
		return
	_sfx("crispy")
	view_layer = Control.new()
	view_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	view_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(view_layer)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.35)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.pressed:
			_close_view_popup())
	view_layer.add_child(dim)

	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", BSkin.box(BSkin.DARK, BSkin.OFFWHITE, 5, 24, 26))
	var top_y := _safe_top() + 166.0
	panel.anchor_left = 1.0
	panel.anchor_right = 1.0
	panel.anchor_top = 0.0
	panel.anchor_bottom = 0.0
	panel.offset_left = -(28.0 + 960.0)
	panel.offset_right = -28.0
	panel.offset_top = top_y
	panel.offset_bottom = top_y + 10.0
	view_layer.add_child(panel)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	panel.add_child(v)

	v.add_child(_popup_title("Ver"))
	var r1 := HBoxContainer.new()
	r1.add_theme_constant_override("separation", 10)
	v.add_child(r1)
	var view_icons := ["view_detail", "view_compact", "view_grid"]
	for i in 3:
		r1.add_child(_popup_opt(view_icons[i], VIEW_NAMES[i], view_mode == i, _set_view.bind(i)))
	var sp1 := Control.new()
	sp1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	r1.add_child(sp1)
	r1.add_child(_popup_opt("hidden", "Oculto", show_hidden, _popup_hidden))

	v.add_child(_popup_title("Ordenar"))
	var r2 := HBoxContainer.new()
	r2.add_theme_constant_override("separation", 10)
	v.add_child(r2)
	var sort_icons := ["sort_az", "sort_size", "sort_date", "sort_type"]
	var sort_names := ["Nombre", "Tamano", "Fecha", "Tipo"]
	for i in 4:
		r2.add_child(_popup_opt(sort_icons[i], sort_names[i], sort_mode == i, _set_sort.bind(i)))
	var sp2 := Control.new()
	sp2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	r2.add_child(sp2)
	r2.add_child(_popup_opt("desc", "Desc", sort_desc, _flip_sort))


func _popup_title(t: String) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_override("font", BSkin.font_title)
	l.add_theme_font_size_override("font_size", 44)
	l.add_theme_color_override("font_color", BSkin.LILAC_TEXT)
	return l


func _popup_opt(kind: String, label: String, active: bool, cb: Callable) -> Control:
	var b := Button.new()
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(150, 160)
	var flat := StyleBoxEmpty.new()
	for stn in ["normal", "hover", "pressed"]:
		b.add_theme_stylebox_override(stn, flat)
	var v := VBoxContainer.new()
	v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 6)
	b.add_child(v)
	var c: Color = BSkin.YELLOW if active else BSkin.OFFWHITE
	var ic := Ico.new(kind, c, 70.0)
	ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(ic)
	var l := Label.new()
	l.text = label
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", _scaled_font(28))
	l.add_theme_color_override("font_color", c)
	v.add_child(l)
	var bar := ColorRect.new()
	bar.custom_minimum_size = Vector2(0, 8)
	bar.color = BSkin.YELLOW if active else Color(0, 0, 0, 0)
	v.add_child(bar)
	_ignore_mouse(v)
	b.pressed.connect(func():
		_sfx("crispy")
		cb.call())
	return b


func _close_view_popup() -> void:
	if view_layer != null:
		view_layer.queue_free()
		view_layer = null


func _set_view(mode: int) -> void:
	_close_view_popup()
	view_mode = mode
	_save_settings()
	_rebuild_rows(false)


func _popup_hidden() -> void:
	_close_view_popup()
	_toggle_hidden()


func _set_sort(mode: int) -> void:
	_close_view_popup()
	sort_mode = mode
	_save_settings()
	_apply_and_rebuild()


func _flip_sort() -> void:
	_close_view_popup()
	sort_desc = not sort_desc
	_save_settings()
	_apply_and_rebuild()


func _toggle_search() -> void:
	search_edit.visible = not search_edit.visible
	if search_edit.visible:
		search_edit.grab_focus()
	else:
		search_edit.text = ""
		query = ""
		_apply_and_rebuild()


func _zip_menu(e: Dictionary) -> void:
	var path: String = e.path
	_menu_modal(String(e.name), [
		["Extraer aqui", _extract.bind(path, cwd)],
		["Extraer en carpeta", _extract.bind(path, FsOps.unique_path(FsOps.join(cwd, path.get_file().get_basename())))],
		["Ver contenido", _zip_contents.bind(path)],
		["Abrir con app", _open_with.bind(path)],
		["Propiedades", _show_properties.bind(e)],
	])


func _extract(zip_path: String, dst: String) -> void:
	var ops := FsOps.new()
	var work := func() -> int:
		return ops.extract(zip_path, dst)
	_run_job("Extrayendo...", ops, work, "Extraido en " + dst.get_file(), "smoke-cloud")


func _zip_contents(zip_path: String) -> void:
	var files := FsOps.zip_list(zip_path)
	var text := ""
	var shown := mini(files.size(), 400)
	for i in shown:
		text += files[i] + "\n"
	if files.size() > shown:
		text += "... y %d mas" % (files.size() - shown)
	if files.is_empty():
		text = "(vacio o ilegible)"
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, 800)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.add_theme_font_size_override("font_size", _scaled_font(32))
	sc.add_child(l)
	_modal("%d archivos" % files.size(), sc, [["Cerrar", Callable(), true]], 220)


func _show_properties(e: Dictionary) -> void:
	var path: String = e.path
	var is_dir: bool = e.is_dir
	var size_text := FsOps.format_size(FsOps.dir_size(path)) if is_dir else FsOps.format_size(e.size)
	var text := "Nombre: %s\nRuta: %s\nTipo: %s\nTamano: %s\nModificado: %s" % [
		e.get("disp", e.name), path.get_base_dir(), "Carpeta" if is_dir else (FsOps.ext_of(path).to_upper() + " archivo").strip_edges(),
		size_text, FsOps.format_time(e.mtime)]
	var body := VBoxContainer.new()
	body.add_theme_constant_override("separation", 16)
	if not is_dir and FsOps.kind_of(path, false) == "image" and int(e.size) < 8 * 1024 * 1024:
		var img := Image.load_from_file(path)
		if img != null and not img.is_empty():
			var big := maxi(img.get_width(), img.get_height())
			if big > 1024:
				var k := 1024.0 / float(big)
				img.resize(maxi(1, int(img.get_width() * k)), maxi(1, int(img.get_height() * k)), Image.INTERPOLATE_BILINEAR)
			var tr := TextureRect.new()
			tr.texture = ImageTexture.create_from_image(img)
			tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			tr.custom_minimum_size = Vector2(0, 520)
			body.add_child(tr)
	body.add_child(_label_body(text))
	_modal("Propiedades", body, [["Cerrar", Callable(), true]], 200)


# =====================================================================
# Miniaturas de imagenes (en hilo, solo filas visibles)
# =====================================================================

func _ico_or_thumb(kind: String, icol: Color, sz: float, path: String) -> Control:
	if kind == "image":
		if thumb_cache.has(path):
			var tex: Variant = thumb_cache[path]
			if tex != null:
				var tr := TextureRect.new()
				tr.texture = tex
				tr.custom_minimum_size = Vector2(sz, sz)
				tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
				tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
				tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
				return tr
		else:
			_request_thumb(path)
	return Ico.new(kind, icol, sz)


func _request_thumb(path: String) -> void:
	if _thumb_pending.has(path):
		return
	_thumb_pending[path] = true
	_thumb_queue.append(path)
	_pump_thumbs.call_deferred()


func _pump_thumbs() -> void:
	if _thumb_thread != null:
		return
	while not _thumb_queue.is_empty():
		var p: String = _thumb_queue.pop_back()
		_thumb_pending.erase(p)
		var idx: int = index_of.get(p, -1)
		if idx < 0 or not active_rows.has(idx):
			continue
		if FsOps.file_size(p) > 6 * 1024 * 1024:
			thumb_cache[p] = null
			continue
		_thumb_pending[p] = true
		_thumb_thread = Thread.new()
		_thumb_thread.start(_thumb_worker.bind(p))
		return


func _thumb_worker(p: String) -> void:
	var img := Image.load_from_file(p)
	if img != null and not img.is_empty():
		var big := maxi(img.get_width(), img.get_height())
		if big > 160:
			var k := 160.0 / float(big)
			img.resize(maxi(1, int(img.get_width() * k)), maxi(1, int(img.get_height() * k)), Image.INTERPOLATE_BILINEAR)
		_thumb_ready.call_deferred(p, img)
	else:
		_thumb_ready.call_deferred(p, null)


func _thumb_ready(p: String, img: Image) -> void:
	if _thumb_thread != null:
		_thumb_thread.wait_to_finish()
		_thumb_thread = null
	_thumb_pending.erase(p)
	if thumb_cache.size() > 400:
		thumb_cache.clear()
	thumb_cache[p] = ImageTexture.create_from_image(img) if img != null else null
	_rebuild_row(p)
	_pump_thumbs()


# =====================================================================
# Reproductor de audio (con visualizador) al tocar un audio
# =====================================================================

func _entry_for_path(path: String) -> Dictionary:
	var ex: Dictionary = entry_by_path.get(path, {})
	if not ex.is_empty() and ex.get("ok", false):
		return ex
	var d: Array = FsOps.details(path, false, true)
	return {"name": path.get_file(), "disp": path.get_file(), "path": path, "is_dir": false,
			"size": d[0], "mtime": d[1], "count": -1, "ok": true}


func _audio_open(path: String) -> void:
	aq = []
	for e in view_arr:
		if not e.is_dir and FsOps.ext_of(e.path) in MUSIC_EXT:
			aq.append(String(e.path))
	aq_i = aq.find(path)
	if aq_i < 0:
		aq = []
	_audio_player(path, true)


func _audio_step(dir: int) -> void:
	if aq.size() <= 1:
		return
	aq_i = (aq_i + dir + aq.size()) % aq.size()
	if player_open:
		_audio_player(String(aq[aq_i]), true)
	else:
		_play_path(String(aq[aq_i]))


func _audio_player(path: String, autoplay: bool) -> void:
	var playable: bool = FsOps.ext_of(path) in MUSIC_EXT
	if playable and autoplay:
		_play_path(path)
	var body := VBoxContainer.new()
	body.add_theme_constant_override("separation", 14)
	var panel := PlayerPanel.new()
	panel.setup(self, playable, aq.size() > 1)
	body.add_child(panel)
	var sep := ColorRect.new()
	sep.color = BSkin.LILAC_DARK
	sep.custom_minimum_size = Vector2(0, 4)
	body.add_child(sep)
	if playable:
		body.add_child(_opt_btn("Importar a mi musica", _import_music.bind([path])))
	body.add_child(_opt_btn("Abrir con app", _open_with.bind(path)))
	body.add_child(_opt_btn("Propiedades", _show_properties.bind(_entry_for_path(path))))
	_modal(path.get_file().get_basename(), body, [["Cerrar", Callable(), false]], 200)
	player_open = true


func _opt_btn(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.clip_text = true
	b.custom_minimum_size = Vector2(0, 100)
	b.pressed.connect(func():
		_sfx("crispy")
		_close_modal()
		cb.call())
	return b


# =====================================================================
# APK
# =====================================================================

func _apk_menu(e: Dictionary) -> void:
	_menu_modal(String(e.get("disp", e.name)), [
		["Instalar", _install_apk.bind(String(e.path))],
		["Ver contenido", _zip_browser.bind(String(e.path), "")],
		["Propiedades", _show_properties.bind(e)],
	])


func _install_apk(path: String) -> void:
	if OS.get_name() != "Android":
		_toast("Instalar APK solo funciona en Android")
		return
	_toast("Si no abre, permite 'Instalar apps desconocidas' a Funkin' Archiver")
	var err: int = OS.shell_open("file://" + path)
	if err != OK:
		_sfx("spark-3")
		_toast("No se pudo lanzar el instalador (error %d)" % err)


# =====================================================================
# Explorar zips sin descomprimir
# =====================================================================

func _tmp_dir() -> String:
	var d := FsOps.join(root_path, ".funkin_archiver_tmp")
	DirAccess.make_dir_recursive_absolute(d)
	if not DirAccess.dir_exists_absolute(d):
		d = ProjectSettings.globalize_path("user://zip_tmp")
		DirAccess.make_dir_recursive_absolute(d)
	return d


func _rm_rf(p: String) -> void:
	if not DirAccess.dir_exists_absolute(p):
		return
	var d := DirAccess.open(p)
	if d == null:
		return
	d.include_hidden = true
	for sub in d.get_directories():
		_rm_rf(FsOps.join(p, sub))
	for f in d.get_files():
		DirAccess.remove_absolute(FsOps.join(p, f))
	DirAccess.remove_absolute(p)


func _clean_tmp() -> void:
	_rm_rf(FsOps.join(root_path, ".funkin_archiver_tmp"))
	_rm_rf(ProjectSettings.globalize_path("user://zip_tmp"))


func _zip_row(label: String, kind: String, icol: Color, cb: Callable) -> Button:
	var b := Button.new()
	b.text = label
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.focus_mode = Control.FOCUS_NONE
	b.clip_text = true
	b.custom_minimum_size = Vector2(0, 104)
	b.add_theme_font_size_override("font_size", 36)
	var n := BSkin.box(BSkin.DARK, BSkin.LILAC_DARK, 3, 16, 14)
	n.content_margin_left = 120
	var hv := BSkin.box(BSkin.LILAC_DARK, BSkin.LILAC_DARK, 3, 16, 14)
	hv.content_margin_left = 120
	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", hv)
	b.add_theme_stylebox_override("pressed", hv)
	var ic := Ico.new(kind, icol, 10.0)
	ic.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	ic.offset_left = 30
	ic.offset_right = 100
	ic.offset_top = 18
	ic.offset_bottom = -18
	b.add_child(ic)
	b.pressed.connect(func():
		_sfx("crispy")
		_close_modal()
		cb.call())
	return b


func _zip_parent_prefix(inner: String) -> String:
	var t := inner.rstrip("/")
	var i := t.rfind("/")
	return "" if i == -1 else t.substr(0, i + 1)


func _zip_browser(zip_path: String, prefix: String) -> void:
	if zip_path != _zb_path or _zb_files.is_empty():
		_zb_files = FsOps.zip_list(zip_path)
		_zb_path = zip_path
	if _zb_files.is_empty():
		_zb_path = ""
		_toast("No se pudo leer el zip (o esta vacio)")
		_sfx("spark-3")
		return
	var dirs: Dictionary = {}
	var files: Array = []
	for f in _zb_files:
		if not f.begins_with(prefix):
			continue
		var rest: String = f.substr(prefix.length())
		if rest == "":
			continue
		var sl := rest.find("/")
		if sl == -1:
			files.append(rest)
		else:
			dirs[rest.substr(0, sl)] = true
	var dnames: Array = dirs.keys()
	var cmp := func(a, b): return String(a).naturalnocasecmp_to(String(b)) < 0
	dnames.sort_custom(cmp)
	files.sort_custom(cmp)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 10)
	var shown := 0
	for dn in dnames:
		if shown >= 400:
			break
		v.add_child(_zip_row(String(dn) + "/", "folder", BSkin.YELLOW, _zip_browser.bind(zip_path, prefix + String(dn) + "/")))
		shown += 1
	for fn in files:
		if shown >= 400:
			break
		var kind := FsOps.kind_of(String(fn), false)
		var col: Color = BSkin.LILAC_TEXT
		match kind:
			"audio":
				col = BSkin.PINK
			"image":
				col = BSkin.BLUE
			"zip":
				col = BSkin.YELLOW
			"apk":
				col = BSkin.GREEN
		v.add_child(_zip_row(String(fn), kind, col, _zip_entry_menu.bind(zip_path, prefix + String(fn))))
		shown += 1
	var total := dnames.size() + files.size()
	if total == 0:
		var el := Label.new()
		el.text = "(vacio)"
		v.add_child(el)
	elif total > shown:
		var more := Label.new()
		more.text = "... y %d mas (extraelos para verlos)" % (total - shown)
		more.add_theme_color_override("font_color", BSkin.LILAC_TEXT)
		v.add_child(more)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, 1100)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	sc.add_child(v)
	var body := VBoxContainer.new()
	body.add_theme_constant_override("separation", 12)
	var crumb_bar := HBoxContainer.new()
	crumb_bar.add_theme_constant_override("separation", 6)
	body.add_child(crumb_bar)
	var root_crumb := _btn(zip_path.get_file(), _zip_browser.bind(zip_path, ""), 92)
	root_crumb.custom_minimum_size.x = 0
	root_crumb.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	crumb_bar.add_child(root_crumb)
	var accumulated := ""
	for segment in prefix.trim_suffix("/").split("/", false):
		accumulated += segment + "/"
		var crumb_path := accumulated
		var crumb := _btn("› " + segment, _zip_browser.bind(zip_path, crumb_path), 92)
		crumb.custom_minimum_size.x = 0
		crumb.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		crumb_bar.add_child(crumb)
	var count_l := Label.new()
	count_l.text = "%d carpetas · %d archivos" % [dnames.size(), files.size()]
	count_l.add_theme_color_override("font_color", BSkin.LILAC_TEXT)
	count_l.add_theme_font_size_override("font_size", 26)
	body.add_child(count_l)
	body.add_child(sc)
	var up_cb := Callable()
	if prefix != "":
		up_cb = _zip_browser.bind(zip_path, _zip_parent_prefix(prefix))
	_modal(zip_path.get_file(), body, [
		["Subir" if prefix != "" else "Atras", up_cb, false],
		["Extraer", _zip_extract_menu.bind(zip_path, prefix), true],
		["Cerrar", Callable(), false],
	], 160)


func _zip_extract_menu(zip_path: String, prefix: String) -> void:
	var here := zip_path.get_base_dir()
	var items: Array = []
	if prefix != "":
		items.append(["Extraer esta carpeta aqui", _zip_extract.bind(zip_path, here, prefix)])
	items.append(["Extraer todo aqui", _zip_extract.bind(zip_path, here, "")])
	items.append(["Extraer todo en carpeta", _zip_extract.bind(zip_path, FsOps.unique_path(FsOps.join(here, zip_path.get_file().get_basename())), "")])
	items.append(["Abrir con app", _open_with.bind(zip_path)])
	items.append(["Propiedades", _show_properties.bind(_entry_for_path(zip_path))])
	items.append(["Volver a la lista", _zip_browser.bind(zip_path, prefix)])
	_menu_modal(zip_path.get_file(), items)


func _zip_extract(zip_path: String, dst: String, prefix: String) -> void:
	var ops := FsOps.new()
	var work := func() -> int:
		return ops.extract(zip_path, dst, prefix)
	_run_job("Extrayendo...", ops, work, "Extraido en " + dst.get_file(), "smoke-cloud")


func _zip_entry_menu(zip_path: String, inner: String) -> void:
	_menu_modal(inner.get_file(), [
		["Abrir", _zip_open_inner.bind(zip_path, inner)],
		["Extraer este archivo aqui", _zip_extract.bind(zip_path, zip_path.get_base_dir(), inner)],
		["Volver a la lista", _zip_browser.bind(zip_path, _zip_parent_prefix(inner))],
	])


func _zip_extract_tmp(zip_path: String, inner: String) -> String:
	var dir := FsOps.join(_tmp_dir(), str(absi(zip_path.hash())))
	DirAccess.make_dir_recursive_absolute(dir)
	var out := FsOps.join(dir, inner.get_file())
	var r := ZIPReader.new()
	if r.open(zip_path) != OK:
		return ""
	var data := r.read_file(inner)
	r.close()
	var w := FileAccess.open(out, FileAccess.WRITE)
	if w == null:
		return ""
	w.store_buffer(data)
	w.close()
	return out


func _zip_open_inner(zip_path: String, inner: String) -> void:
	var tmp := _zip_extract_tmp(zip_path, inner)
	if tmp == "":
		_toast("No se pudo leer ese archivo del zip")
		_sfx("electrocution")
		return
	var ext := FsOps.ext_of(inner)
	var kind := FsOps.kind_of(inner, false)
	var back := _zip_browser.bind(zip_path, _zip_parent_prefix(inner))
	if kind == "audio":
		aq = []
		_audio_player(tmp, true)
	elif kind == "image":
		var img := Image.load_from_file(tmp)
		if img == null or img.is_empty():
			_open_with(tmp)
			return
		var big := maxi(img.get_width(), img.get_height())
		if big > 1400:
			var k := 1400.0 / float(big)
			img.resize(maxi(1, int(img.get_width() * k)), maxi(1, int(img.get_height() * k)), Image.INTERPOLATE_BILINEAR)
		var tr := TextureRect.new()
		tr.texture = ImageTexture.create_from_image(img)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tr.custom_minimum_size = Vector2(0, 1000)
		_modal(inner.get_file(), tr, [["Volver", back, false], ["Cerrar", Callable(), true]], 200)
	elif ext in TEXT_EXT:
		var txt := FileAccess.get_file_as_string(tmp)
		if txt.length() > 60000:
			txt = txt.substr(0, 60000) + "\n... (recortado)"
		var sc := ScrollContainer.new()
		sc.custom_minimum_size = Vector2(0, 1100)
		sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		var l := Label.new()
		l.text = txt
		l.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l.add_theme_font_size_override("font_size", _scaled_font(28))
		sc.add_child(l)
		_modal(inner.get_file(), sc, [["Volver", back, false], ["Cerrar", Callable(), true]], 160)
	elif kind == "zip":
		_zip_browser(tmp, "")
	elif kind == "apk":
		_install_apk(tmp)
	else:
		_open_with(tmp)


# =====================================================================
# Trabajos en hilo con barra de progreso
# =====================================================================

func _run_job(title: String, ops: FsOps, work: Callable, ok_msg: String, sound: String) -> void:
	if _thread != null:
		return
	_show_progress(title)
	ops.on_progress = func(p: float, label: String): _progress_update.call_deferred(p, label)
	_thread = Thread.new()
	_thread.start(func():
		var r: int = work.call()
		_job_finished.call_deferred(r, ok_msg, sound))


func _job_finished(err: int, ok_msg: String, sound: String) -> void:
	if _thread != null:
		_thread.wait_to_finish()
		_thread = null
	_close_progress()
	if err == OK:
		_sfx(sound)
		_toast(ok_msg)
	else:
		_sfx("electrocution")
		_toast("Error: " + error_string(err))
	selection_mode = false
	selected.clear()
	refresh()
	_update_bars()


func _progress_update(p: float, label: String) -> void:
	if progress_bar:
		progress_bar.set_progress(p)
	if progress_label:
		progress_label.text = "%d%%  %s" % [int(floor(clampf(p, 0.0, 1.0) * 100.0)), label]


func _maybe_show_loading(gen: int) -> void:
	if gen == _list_gen and _listing_busy:
		_show_loading()


func _show_loading() -> void:
	if load_layer != null:
		return
	load_layer = Control.new()
	load_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	load_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(load_layer)
	var mc := MarginContainer.new()
	mc.set_anchors_preset(Control.PRESET_FULL_RECT)
	mc.add_theme_constant_override("margin_bottom", int(_safe_bottom()) + 70)
	load_layer.add_child(mc)
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	panel.size_flags_vertical = Control.SIZE_SHRINK_END
	panel.custom_minimum_size = Vector2(560, 0)
	panel.add_theme_stylebox_override("panel", BSkin.box(BSkin.DARK, BSkin.OFFWHITE, 5, 26, 18))
	mc.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	panel.add_child(v)
	load_bar = LoadingBar.new()
	load_bar.custom_minimum_size = Vector2(0, 160)
	load_bar.set_progress(0.0)
	v.add_child(load_bar)
	load_label = Label.new()
	load_label.text = "Leyendo carpeta... 0%"
	load_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	load_label.clip_text = true
	load_label.add_theme_font_size_override("font_size", _scaled_font(28))
	load_label.add_theme_color_override("font_color", BSkin.LILAC_TEXT)
	v.add_child(load_label)
	_ignore_mouse(mc)
	_update_loading()


func _update_loading() -> void:
	if load_bar == null:
		return
	if loading:
		load_bar.set_progress(0.0)
		load_label.text = "Leyendo carpeta... 0%"
		return
	var total := maxi(entries.size(), 1)
	var p := clampf(float(_details_n) / float(total), 0.0, 1.0)
	load_bar.set_progress(p)
	load_label.text = "Cargando %d%%" % int(floor(p * 100.0))


func _hide_loading(_animate: bool = true) -> void:
	## Se quita al instante: sin tween, sin esperar a que la barra llegue al 100 %.
	if load_layer != null:
		load_layer.queue_free()
	load_layer = null
	load_bar = null
	load_label = null


func _show_progress(title: String) -> void:
	_close_progress()
	progress_layer = Control.new()
	progress_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	progress_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(progress_layer)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.7)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	progress_layer.add_child(dim)
	var mc := MarginContainer.new()
	mc.set_anchors_preset(Control.PRESET_FULL_RECT)
	mc.add_theme_constant_override("margin_top", int(maxf(120.0, (get_viewport_rect().size.y - 700.0) * 0.4)))
	mc.add_theme_constant_override("margin_left", 50)
	mc.add_theme_constant_override("margin_right", 50)
	progress_layer.add_child(mc)
	var panel := PanelContainer.new()
	panel.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	panel.add_theme_stylebox_override("panel", BSkin.box(BSkin.DARK, BSkin.OFFWHITE, 6, 28, 30))
	mc.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 22)
	panel.add_child(v)
	var t := Label.new()
	t.text = title
	t.add_theme_font_override("font", BSkin.font_title)
	t.add_theme_font_size_override("font_size", 56)
	t.add_theme_color_override("font_color", BSkin.YELLOW)
	v.add_child(t)
	progress_bar = LoadingBar.new()
	progress_bar.custom_minimum_size = Vector2(0, 230)
	progress_bar.set_progress(0.0)
	v.add_child(progress_bar)
	progress_label = Label.new()
	progress_label.clip_text = true
	progress_label.text = "0%"
	progress_label.add_theme_font_size_override("font_size", _scaled_font(32))
	progress_label.add_theme_color_override("font_color", BSkin.LILAC_TEXT)
	v.add_child(progress_label)


func _close_progress() -> void:
	if progress_layer != null:
		progress_layer.queue_free()
		progress_layer = null
	progress_bar = null
	progress_label = null


# =====================================================================
# Modales y avisos
# =====================================================================

func _label_body(text: String) -> Label:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	l.add_theme_font_size_override("font_size", 38)
	return l


func _modal(title: String, body: Control, buttons: Array, top_margin: int = 380) -> void:
	_close_modal()
	modal_layer = Control.new()
	modal_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	modal_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(modal_layer)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.65)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	modal_layer.add_child(dim)
	var mc := MarginContainer.new()
	mc.set_anchors_preset(Control.PRESET_FULL_RECT)
	mc.add_theme_constant_override("margin_top", top_margin)
	mc.add_theme_constant_override("margin_left", 50)
	mc.add_theme_constant_override("margin_right", 50)
	mc.add_theme_constant_override("margin_bottom", 40)
	modal_layer.add_child(mc)
	var panel := PanelContainer.new()
	panel.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	panel.add_theme_stylebox_override("panel", BSkin.box(BSkin.DARK, BSkin.OFFWHITE, 6, 28, 30))
	mc.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 22)
	panel.add_child(v)
	var t := Label.new()
	t.text = title
	t.clip_text = true
	t.add_theme_font_override("font", BSkin.font_title)
	t.add_theme_font_size_override("font_size", 56)
	t.add_theme_color_override("font_color", BSkin.YELLOW)
	v.add_child(t)
	if body != null:
		v.add_child(body)
	if not buttons.is_empty():
		var hb := HBoxContainer.new()
		hb.add_theme_constant_override("separation", 16)
		v.add_child(hb)
		for spec in buttons:
			var cb: Callable = spec[1]
			var b := Button.new()
			b.text = spec[0]
			b.focus_mode = Control.FOCUS_NONE
			b.custom_minimum_size = Vector2(0, 110)
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			if spec[2]:
				b.add_theme_stylebox_override("normal", BSkin.box(BSkin.YELLOW))
				b.add_theme_color_override("font_color", BSkin.DARK)
				b.add_theme_color_override("font_hover_color", BSkin.DARK)
			b.pressed.connect(func():
				_sfx("crispy")
				_close_modal()
				if cb.is_valid():
					cb.call())
			hb.add_child(b)


func _modal_input(title: String, default_text: String, ok_text: String, cb: Callable) -> void:
	var le := LineEdit.new()
	le.text = default_text
	le.select_all_on_focus = true
	var ok := func(): cb.call(le.text)
	_modal(title, le, [
		["Cancelar", Callable(), false],
		[ok_text, ok, true],
	], 260)
	le.grab_focus.call_deferred()


func _menu_modal(title: String, items: Array) -> void:
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 14)
	for it in items:
		var cb: Callable = it[1]
		var b := Button.new()
		b.text = it[0]
		b.focus_mode = Control.FOCUS_NONE
		b.clip_text = true
		b.custom_minimum_size = Vector2(0, 110)
		b.pressed.connect(func():
			_sfx("crispy")
			_close_modal()
			cb.call())
		v.add_child(b)
	var sc := ScrollContainer.new()
	var available_h := maxf(220.0, get_viewport_rect().size.y - 560.0)
	sc.custom_minimum_size = Vector2(0, minf(items.size() * 124.0, available_h))
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_ALWAYS
	_style_scrollbar(sc, 24)
	sc.add_child(v)
	_modal(title, sc, [["Cerrar", Callable(), false]])


func _close_modal() -> void:
	player_open = false
	if modal_layer != null:
		modal_layer.queue_free()
		modal_layer = null


func _build_toast() -> void:
	toast_panel = PanelContainer.new()
	toast_panel.add_theme_stylebox_override("panel", BSkin.box(BSkin.YELLOW, BSkin.OFFWHITE, 5, 24, 22))
	toast_panel.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	toast_panel.offset_left = 60
	toast_panel.offset_right = -60
	toast_panel.offset_top = -330
	toast_panel.offset_bottom = -210
	toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_panel.modulate.a = 0.0
	add_child(toast_panel)
	toast_label = Label.new()
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	toast_label.add_theme_color_override("font_color", BSkin.DARK)
	toast_label.add_theme_font_size_override("font_size", 38)
	toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_panel.add_child(toast_label)


func _toast(msg: String) -> void:
	toast_label.text = msg
	if toast_tween:
		toast_tween.kill()
	toast_panel.modulate.a = 1.0
	toast_tween = create_tween()
	toast_tween.tween_interval(2.2)
	toast_tween.tween_property(toast_panel, "modulate:a", 0.0, 0.4)


# =====================================================================
# Ajustes, log y menus nuevos
# =====================================================================

func _log(msg: String) -> void:
	var f := FileAccess.open(LOG_PATH, FileAccess.READ_WRITE)
	if f == null:
		f = FileAccess.open(LOG_PATH, FileAccess.WRITE)
	if f == null:
		return
	if f.get_length() > 200000:
		f.close()
		f = FileAccess.open(LOG_PATH, FileAccess.WRITE)
		if f == null:
			return
	f.seek_end()
	f.store_line("[%d] %s" % [Time.get_ticks_msec(), msg])
	f.close()


func _load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) != OK:
		return
	toolbar_idx = clampi(int(cf.get_value("ui", "toolbar", 0)), 0, TOOLBAR_COLORS.size() - 1)
	folder_idx = clampi(int(cf.get_value("ui", "folder", 5)), 0, FOLDER_COLORS.size() - 1)
	fab_on = bool(cf.get_value("ui", "fab", true))
	bg_on = bool(cf.get_value("ui", "bg", true))
	show_hidden = bool(cf.get_value("ui", "hidden", false))
	sfx_on = bool(cf.get_value("ui", "sfx", true))
	view_mode = clampi(int(cf.get_value("ui", "view", 0)), 0, 2)
	dual_tab = bool(cf.get_value("ui", "dual", true))
	sort_mode = clampi(int(cf.get_value("ui", "sort", 0)), 0, 3)
	sort_desc = bool(cf.get_value("ui", "desc", false))
	font_scale = clampi(int(cf.get_value("ui", "font_scale", 100)), 80, 160)
	file_info_scale = clampi(int(cf.get_value("ui", "file_info_scale", 100)), 80, 160)
	file_row_scale = clampi(int(cf.get_value("ui", "file_row_scale", 100)), 80, 140)
	if theme != null:
		theme.default_font_size = int(32.0 * float(font_scale) / 100.0)


func _save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("ui", "toolbar", toolbar_idx)
	cf.set_value("ui", "folder", folder_idx)
	cf.set_value("ui", "fab", fab_on)
	cf.set_value("ui", "bg", bg_on)
	cf.set_value("ui", "hidden", show_hidden)
	cf.set_value("ui", "sfx", sfx_on)
	cf.set_value("ui", "view", view_mode)
	cf.set_value("ui", "dual", dual_tab)
	cf.set_value("ui", "sort", sort_mode)
	cf.set_value("ui", "desc", sort_desc)
	cf.set_value("ui", "font_scale", font_scale)
	cf.set_value("ui", "file_info_scale", file_info_scale)
	cf.set_value("ui", "file_row_scale", file_row_scale)
	cf.save(SETTINGS_PATH)


func _settings_menu() -> void:
	## Pantalla completa de ajustes: independiente de los menus emergentes.
	_close_modal()
	modal_layer = Control.new()
	modal_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	modal_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(modal_layer)

	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	panel.add_theme_stylebox_override("panel", BSkin.box(BSkin.DARK, BSkin.OFFWHITE, 0, 0, 0))
	modal_layer.add_child(panel)

	var outer := MarginContainer.new()
	outer.set_anchors_preset(Control.PRESET_FULL_RECT)
	outer.add_theme_constant_override("margin_top", int(_safe_top()) + 18)
	outer.add_theme_constant_override("margin_bottom", int(_safe_bottom()) + 18)
	outer.add_theme_constant_override("margin_left", 24)
	outer.add_theme_constant_override("margin_right", 24)
	panel.add_child(outer)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 14)
	outer.add_child(root)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 14)
	root.add_child(header)
	var back := _btn("←", func():
		_close_modal()
		_toggle_drawer(true), 92)
	header.add_child(back)
	var heading := Label.new()
	heading.text = "AJUSTES"
	heading.add_theme_font_override("font", BSkin.font_title)
	heading.add_theme_font_size_override("font_size", 58)
	heading.add_theme_color_override("font_color", BSkin.YELLOW)
	heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	heading.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(heading)

	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(sc)
	var content := VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 22)
	sc.add_child(content)

	_settings_section(content, "OPCIONES")
	_settings_slider(content, "Tamaño de fuentes", font_scale, 80, 160, 5,
		func(v: float):
			font_scale = int(v)
			if theme != null:
				theme.default_font_size = int(32.0 * float(font_scale) / 100.0)
			_save_settings()
			_rebuild_rows(true))
	_settings_slider(content, "Información de archivos", file_info_scale, 80, 160, 5,
		func(v: float):
			file_info_scale = int(v)
			_save_settings()
			_rebuild_rows(true))
	_settings_section(content, "FICHEROS")
	_settings_slider(content, "Altura de filas", file_row_scale, 80, 140, 5,
		func(v: float):
			file_row_scale = int(v)
			_save_settings()
			_rebuild_rows(true))
	_settings_section(content, "INTERFAZ")
	_settings_action(content, "Interfaz y colores", _ui_menu)
	_settings_action(content, "Música del menú: " + ("Activada" if music_on else "Pausada"), _toggle_music)
	_settings_action(content, "Sonidos: " + ("Activados" if sfx_on else "Desactivados"), _toggle_sfx)
	_settings_action(content, "Restaurar ajustes visuales", _reset_visual_settings)
	_settings_section(content, "ACCESO AVANZADO")
	_settings_action(content, "Configurar Shizuku", _shizuku_info)


func _settings_section(parent: VBoxContainer, caption: String) -> void:
	var label := Label.new()
	label.text = caption
	label.add_theme_font_override("font", BSkin.font_title)
	label.add_theme_font_size_override("font_size", 38)
	label.add_theme_color_override("font_color", BSkin.YELLOW)
	parent.add_child(label)


func _settings_slider(parent: VBoxContainer, caption: String, current: int,
		minimum: float, maximum: float, step: float, changed: Callable) -> void:
	var group := VBoxContainer.new()
	group.add_theme_constant_override("separation", 8)
	parent.add_child(group)
	var line := HBoxContainer.new()
	group.add_child(line)
	var label := Label.new()
	label.text = caption
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.add_theme_font_size_override("font_size", _scaled_font(30))
	line.add_child(label)
	var value_label := Label.new()
	value_label.text = "%d%%" % current
	value_label.add_theme_font_size_override("font_size", _scaled_font(30))
	value_label.add_theme_color_override("font_color", BSkin.YELLOW)
	line.add_child(value_label)
	var slider := HSlider.new()
	slider.min_value = minimum
	slider.max_value = maximum
	slider.step = step
	slider.value = current
	slider.custom_minimum_size = Vector2(0, 64)
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.value_changed.connect(func(v: float):
		value_label.text = "%d%%" % int(v)
		changed.call(v))
	group.add_child(slider)


func _settings_action(parent: VBoxContainer, caption: String, cb: Callable) -> void:
	var button := _btn(caption, cb, 96)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(button)


func _cycle_font_scale() -> void:
	font_scale = clampi(font_scale + 5, 80, 160)
	_save_settings()
	if theme != null:
		theme.default_font_size = int(32.0 * float(font_scale) / 100.0)
	_settings_menu()


func _cycle_file_info() -> void:
	file_info_scale = clampi(file_info_scale + 5, 80, 160)
	_save_settings()
	_rebuild_rows(true)
	_settings_menu()


func _reset_visual_settings() -> void:
	font_scale = 100
	file_info_scale = 100
	file_row_scale = 100
	folder_idx = 5
	bg_on = true
	if theme != null:
		theme.default_font_size = 32
	if bg != null:
		bg.visible = true
	_save_settings()
	_rebuild_rows(true)
	_settings_menu()


func _shizuku_info() -> void:
	var bridge_found := Engine.has_singleton("ShizukuBridge")
	var items: Array = []
	if not bridge_found:
		items.append(["Puente nativo no instalado", _toast.bind("Exporta Android incluyendo el plugin ShizukuBridge de la carpeta android/plugins.")])
	else:
		var bridge = Engine.get_singleton("ShizukuBridge")
		var available: bool = bridge.isShizukuAvailable()
		var permitted: bool = bridge.hasShizukuPermission() if available else false
		items.append(["Shizuku: " + ("Iniciado" if available else "No iniciado"), _toast.bind("Abre Shizuku y activa el servicio mediante depuracion inalambrica.")])
		items.append(["Permiso ADB: " + ("Concedido" if permitted else "Pendiente"), _shizuku_request_permission if available and not permitted else _toast.bind("El permiso ADB ya esta concedido." if permitted else "Primero inicia Shizuku.")])
		items.append(["Probar Android/data", _shizuku_test_access if permitted else _shizuku_request_permission])
	items.append(["Abrir permisos de archivos", _ask_permissions])
	_menu_modal("Shizuku / Android data", items)


func _shizuku_request_permission() -> void:
	if not Engine.has_singleton("ShizukuBridge"):
		_toast("Plugin Shizuku no instalado")
		return
	var bridge = Engine.get_singleton("ShizukuBridge")
	if not bridge.isShizukuAvailable():
		_toast("Inicia Shizuku primero")
		return
	bridge.requestShizukuPermission()
	_toast("Solicitud enviada a Shizuku")


func _shizuku_test_access() -> void:
	if not Engine.has_singleton("ShizukuBridge"):
		_toast("Plugin Shizuku no instalado")
		return
	var bridge = Engine.get_singleton("ShizukuBridge")
	var raw: String = bridge.listAndroidData()
	var parsed = JSON.parse_string(raw)
	if not parsed is Dictionary or not parsed.get("ok", false):
		var reason := String(parsed.get("error", "RESPUESTA_INVALIDA")) if parsed is Dictionary else "RESPUESTA_INVALIDA"
		_menu_modal("Android/data", [["No se pudo listar: " + reason, _toast.bind("Comprueba el permiso y que el servicio Shizuku este conectado.")]])
		return
	var items: Array = []
	for entry in parsed.get("items", []):
		var label := String(entry.get("name", "?")) + ("/" if entry.get("is_dir", false) else "")
		items.append([label, _toast.bind(String(entry.get("path", "")))])
	if items.is_empty():
		items.append(["La carpeta esta vacia", Callable()])
	_menu_modal("Android/data · %d elementos" % items.size(), items)


func _ui_menu() -> void:
	_menu_modal("Interfaz", [
		["Color de carpetas: " + String(FOLDER_COLORS[folder_idx][0]), _cycle_folder],
		["Doble pestana: " + ("Si" if dual_tab else "No"), _toggle_dual],
		["Boton flotante: " + ("Si" if fab_on else "No"), _toggle_fab],
		["Mostrar fondo: " + ("Si" if bg_on else "No"), _toggle_bg],
	])


func _music_menu() -> void:
	var items: Array = [[("* " if cur_track == -1 else "") + "Mod Menu Ambience", _play_default]]
	for i in playlist.size():
		items.append([("* " if cur_track == i else "") + String(playlist[i].name), _track_menu.bind(i)])
	items.append(["Importar musica", _import_hint])
	_menu_modal("Mi musica", items)


func _cycle_folder() -> void:
	folder_idx = (folder_idx + 1) % FOLDER_COLORS.size()
	_save_settings()
	_rebuild_rows(true)
	_ui_menu()


func _toggle_fab() -> void:
	fab_on = not fab_on
	_save_settings()
	_update_bars()
	_ui_menu()


func _toggle_bg() -> void:
	bg_on = not bg_on
	bg.visible = bg_on
	_save_settings()
	_ui_menu()


# ---------- lugares (desplegable del titulo, como ZArchiver) ----------

func _places() -> Array:
	var out: Array = []
	if OS.get_name() == "Android":
		out.append(["ROOT", "phone", "/"])
		out.append(["Memoria del dispositivo", "phone", root_path])
		var sd := DirAccess.open("/storage")
		if sd != null:
			for dn in sd.get_directories():
				if dn != "emulated" and dn != "self":
					out.append(["Tarjeta SD", "phone", "/storage/" + dn])
		out.append(["Descargas", "folder", root_path + "/Download"])
		out.append(["Documentos", "folder", root_path + "/Documents"])
		out.append(["Musica", "audio", root_path + "/Music"])
		out.append(["Imagenes", "image", root_path + "/DCIM"])
		out.append(["Android/data", "folder", root_path + "/Android/data"])
		out.append(["Android/obb", "folder", root_path + "/Android/obb"])
	else:
		out.append(["Inicio", "home", root_path])
		out.append(["Descargas", "folder", root_path + "/Downloads"])
		out.append(["Documentos", "folder", root_path + "/Documents"])
		out.append(["Musica", "audio", root_path + "/Music"])
	out.append(["Datos de la app", "file", ProjectSettings.globalize_path("user://")])
	return out


# =====================================================================
# Musica custom
# =====================================================================

func _load_playlist() -> void:
	playlist = []
	if not FileAccess.file_exists(MUSIC_INDEX):
		return
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(MUSIC_INDEX))
	if data is Array:
		for it in data:
			if it is Dictionary and it.has("file") and FileAccess.file_exists(FsOps.join(MUSIC_DIR, str(it.file))):
				playlist.append({"name": str(it.get("name", it.file)), "file": str(it.file)})


func _save_playlist() -> void:
	var f := FileAccess.open(MUSIC_INDEX, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(playlist))
	f.close()


func _wav_from_bytes(b: PackedByteArray) -> AudioStreamWAV:
	if b.size() < 44 or b.slice(0, 4).get_string_from_ascii() != "RIFF" or b.slice(8, 12).get_string_from_ascii() != "WAVE":
		return null
	var pos := 12
	var fmt := 0
	var ch := 2
	var rate := 44100
	var bits := 16
	var data := PackedByteArray()
	while pos + 8 <= b.size():
		var id := b.slice(pos, pos + 4).get_string_from_ascii()
		var sz := b.decode_u32(pos + 4)
		var body := pos + 8
		if id == "fmt " and body + 16 <= b.size():
			fmt = b.decode_u16(body)
			ch = b.decode_u16(body + 2)
			rate = b.decode_u32(body + 4)
			bits = b.decode_u16(body + 14)
		elif id == "data":
			data = b.slice(body, mini(body + sz, b.size()))
			break
		pos = body + sz + (sz & 1)
	if (fmt != 1 and fmt != 0xFFFE) or data.is_empty() or ch < 1 or ch > 2 or (bits != 8 and bits != 16):
		return null
	var w := AudioStreamWAV.new()
	w.mix_rate = rate
	w.stereo = ch == 2
	if bits == 16:
		w.format = AudioStreamWAV.FORMAT_16_BITS
	else:
		w.format = AudioStreamWAV.FORMAT_8_BITS
		for i in data.size():
			data[i] = (data[i] - 128) & 0xFF
	w.data = data
	return w


func _stream_from_file(path: String) -> AudioStream:
	var ext := FsOps.ext_of(path)
	if ext == "ogg":
		return AudioStreamOggVorbis.load_from_file(path)
	var bytes := FileAccess.get_file_as_bytes(path)
	if bytes.is_empty():
		return null
	if ext == "mp3":
		var mp := AudioStreamMP3.new()
		mp.data = bytes
		return mp
	if ext == "wav":
		return _wav_from_bytes(bytes)
	return null


func _play_stream(st: AudioStream, title: String, track: int) -> void:
	if st == null:
		_toast("No se pudo cargar ese audio (usa ogg, mp3 o wav 16-bit)")
		_sfx("electrocution")
		return
	ambience.stream = st
	ambience.volume_db = -12.0 if track == -1 else -8.0
	ambience.stream_paused = false
	ambience.play()
	cur_track = track
	var music_cfg := ConfigFile.new()
	music_cfg.load(SETTINGS_PATH)
	music_cfg.set_value("audio", "last_track", track)
	music_cfg.save(SETTINGS_PATH)
	music_on = true
	if play_ico:
		play_ico.set_kind("pause")
	if now_label:
		now_label.text = "Now Playing: " + title
	_build_drawer_items()


func _resume_saved_music() -> void:
	var cf := ConfigFile.new()
	var last := -1
	if cf.load(SETTINGS_PATH) == OK:
		last = int(cf.get_value("audio", "last_track", -1))
	if last >= 0 and last < playlist.size():
		_play_track(last)
	else:
		_play_default()


func _play_default() -> void:
	_play_stream(default_stream, "Mod Menu Ambience", -1)


func _play_track(i: int) -> void:
	if i < 0 or i >= playlist.size():
		return
	var path := FsOps.join(MUSIC_DIR, String(playlist[i].file))
	_play_stream(_stream_from_file(path), String(playlist[i].name), i)


func _play_path(path: String) -> void:
	_play_stream(_stream_from_file(path), path.get_file().get_basename(), -2)


func _step_track(dir: int) -> void:
	var total := playlist.size() + 1
	var pos := maxi(cur_track + 1, 0)
	var np := (pos + dir + total) % total
	if np == 0:
		_play_default()
	else:
		_play_track(np - 1)


func _next_track() -> void:
	_step_track(1)


func _prev_track() -> void:
	_step_track(-1)


func _on_music_finished() -> void:
	if cur_track >= 0 and not playlist.is_empty():
		_play_track((cur_track + 1) % playlist.size())
	elif cur_track == -2 and aq.size() > 1:
		_audio_step(1)


func _track_menu(i: int) -> void:
	if i < 0 or i >= playlist.size():
		return
	_menu_modal(String(playlist[i].name), [
		["Reproducir", _play_track.bind(i)],
		["Quitar de mi musica", _remove_track.bind(i)],
	])


func _remove_track(i: int) -> void:
	if i < 0 or i >= playlist.size():
		return
	DirAccess.remove_absolute(FsOps.join(MUSIC_DIR, String(playlist[i].file)))
	playlist.remove_at(i)
	_save_playlist()
	if cur_track == i:
		_play_default()
	else:
		if cur_track > i:
			cur_track -= 1
		_build_drawer_items()


func _import_hint() -> void:
	pick_music = true
	_toggle_drawer(false)
	_toast("Toca un audio (mp3, ogg, wav) para importarlo")


func _import_music(paths: Array) -> void:
	DirAccess.make_dir_recursive_absolute(MUSIC_DIR)
	var ok := 0
	for p in paths:
		var src := String(p)
		if not (FsOps.ext_of(src) in MUSIC_EXT):
			continue
		var dst := FsOps.unique_path(FsOps.join(MUSIC_DIR, src.get_file()))
		if DirAccess.copy_absolute(src, dst) == OK:
			playlist.append({"name": src.get_file().get_basename(), "file": dst.get_file()})
			ok += 1
	_save_playlist()
	_build_drawer_items()
	if ok > 0:
		_sfx("smoke-cloud")
		_toast("%d cancion%s importada%s" % [ok, "" if ok == 1 else "es", "" if ok == 1 else "s"])
		# La primera importacion pasa a ser la musica permanente del menu.
		_play_track(playlist.size() - ok)
	else:
		_sfx("electrocution")
		_toast("No se pudo importar (solo ogg, mp3, wav)")


func _import_selected_music() -> void:
	var ps := _sel_paths()
	_clear_selection()
	_import_music(ps)


func _audio_menu(e: Dictionary) -> void:
	var path: String = e.path
	_menu_modal(String(e.get("disp", e.name)), [
		["Reproducir ahora", _play_path.bind(path)],
		["Importar a mi musica", _import_music.bind([path])],
		["Abrir con app", _open_with.bind(path)],
		["Propiedades", _show_properties.bind(e)],
	])


