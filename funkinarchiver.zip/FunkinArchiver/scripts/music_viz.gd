class_name MusicViz
extends Control
## Visualizador de espectro (barras) para la musica que suena.
## Usa el AudioEffectSpectrumAnalyzer del bus "Viz" (lo crea main.gd).

const BARS := 28
const LO := 40.0
const HI := 14000.0

var analyzer: AudioEffectSpectrumAnalyzerInstance
var active: bool = true
var levels := PackedFloat32Array()
var peaks := PackedFloat32Array()


func _init(min_h: float = 240.0) -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(0, min_h)
	levels.resize(BARS)
	peaks.resize(BARS)


func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	for i in BARS:
		var v := 0.0
		if analyzer != null and active:
			var f0 := LO * pow(HI / LO, float(i) / BARS)
			var f1 := LO * pow(HI / LO, float(i + 1) / BARS)
			var m: Vector2 = analyzer.get_magnitude_for_frequency_range(f0, f1)
			var e := (m.x + m.y) * 0.5
			if e > 0.0:
				v = clampf((linear_to_db(e) + 58.0) / 58.0, 0.0, 1.0)
				v = clampf(v * (1.0 + 0.7 * float(i) / BARS), 0.0, 1.0)
		if v > levels[i]:
			levels[i] = lerpf(levels[i], v, minf(1.0, delta * 30.0))
		else:
			levels[i] = maxf(v, levels[i] - delta * 1.4)
		peaks[i] = maxf(levels[i], peaks[i] - delta * 0.45)
	queue_redraw()


func _draw() -> void:
	var w := size.x
	var h := size.y
	draw_rect(Rect2(0, 0, w, h), Color(0.07, 0.06, 0.09, 0.85))
	var gap := 6.0
	var bw := (w - gap * (BARS + 1)) / BARS
	var base := h - 10.0
	var maxh := h - 24.0
	for i in BARS:
		var bh := maxf(4.0, levels[i] * maxh)
		var x := gap + i * (bw + gap)
		var col := BSkin.PINK.lerp(BSkin.YELLOW, clampf(levels[i] * 1.2, 0.0, 1.0))
		draw_rect(Rect2(x, base - bh, bw, bh), col)
		var py := base - maxf(4.0, peaks[i] * maxh) - 7.0
		draw_rect(Rect2(x, py, bw, 4.0), BSkin.OFFWHITE)
