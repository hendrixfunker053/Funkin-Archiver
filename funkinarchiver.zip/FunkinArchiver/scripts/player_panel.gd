class_name PlayerPanel
extends VBoxContainer
## Reproductor que sale al tocar un audio: visualizador, barra de tiempo y controles.
## Usa el AudioStreamPlayer global (`ambience`) de main.gd.

var m: Node
var viz: MusicViz
var slider: HSlider
var t_cur: Label
var t_tot: Label
var play_ico: Ico
var _dragging := false
var _ok := true


func setup(main: Node, ok: bool, multi: bool) -> void:
	m = main
	_ok = ok
	add_theme_constant_override("separation", 14)
	viz = MusicViz.new(240.0)
	viz.analyzer = m.spectrum()
	viz.active = ok
	add_child(viz)
	if not ok:
		var l := Label.new()
		l.text = "Este formato no se reproduce aqui (solo ogg, mp3 y wav). Usa \"Abrir con app\"."
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.add_theme_font_size_override("font_size", 32)
		l.add_theme_color_override("font_color", BSkin.LILAC_TEXT)
		add_child(l)
		return
	var tr := HBoxContainer.new()
	tr.add_theme_constant_override("separation", 14)
	add_child(tr)
	t_cur = _time_label()
	tr.add_child(t_cur)
	slider = HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.0005
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.custom_minimum_size = Vector2(0, 64)
	slider.focus_mode = Control.FOCUS_NONE
	slider.add_theme_stylebox_override("slider", BSkin.box(BSkin.LILAC_DARK, BSkin.LILAC_DARK, 0, 10, 0))
	slider.add_theme_stylebox_override("grabber_area", BSkin.box(BSkin.YELLOW, BSkin.YELLOW, 0, 10, 0))
	slider.add_theme_stylebox_override("grabber_area_highlight", BSkin.box(BSkin.YELLOW, BSkin.YELLOW, 0, 10, 0))
	slider.drag_started.connect(func(): _dragging = true)
	slider.drag_ended.connect(_on_drag_ended)
	tr.add_child(slider)
	t_tot = _time_label()
	tr.add_child(t_tot)
	var cr := HBoxContainer.new()
	cr.add_theme_constant_override("separation", 12)
	add_child(cr)
	var prev := _btn("prev", func(): m._audio_step(-1))
	prev.disabled = not multi
	cr.add_child(prev)
	var pb := _btn("pause", _on_play)
	play_ico = pb.get_child(0) as Ico
	cr.add_child(pb)
	var nxt := _btn("next", func(): m._audio_step(1))
	nxt.disabled = not multi
	cr.add_child(nxt)


func _time_label() -> Label:
	var l := Label.new()
	l.text = "0:00"
	l.custom_minimum_size = Vector2(110, 0)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 30)
	l.add_theme_color_override("font_color", BSkin.LILAC_TEXT)
	return l


func _btn(kind: String, cb: Callable) -> Button:
	var b: Button = m._icon_btn(kind, func(): cb.call(), 110)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return b


func _fmt(t: float) -> String:
	var s := int(maxf(t, 0.0))
	return "%d:%02d" % [s / 60, s % 60]


func _total() -> float:
	var st: AudioStream = m.ambience.stream
	return st.get_length() if st != null else 0.0


func _on_play() -> void:
	if not m.ambience.playing and not m.ambience.stream_paused:
		m.ambience.play()
		m.music_on = true
		if m.play_ico:
			m.play_ico.set_kind("pause")
	else:
		m._toggle_music()


func _on_drag_ended(_changed: bool) -> void:
	var tot := _total()
	if tot > 0.0:
		m.ambience.seek(slider.value * tot)
	_dragging = false


func _process(_d: float) -> void:
	if not _ok or slider == null:
		return
	var tot := _total()
	var pos: float = m.ambience.get_playback_position() if m.ambience.playing or m.ambience.stream_paused else 0.0
	if not _dragging and tot > 0.0:
		slider.set_value_no_signal(clampf(pos / tot, 0.0, 1.0))
	var shown := slider.value * tot if _dragging else pos
	t_cur.text = _fmt(shown)
	t_tot.text = _fmt(tot)
	var playing: bool = m.ambience.playing and not m.ambience.stream_paused
	play_ico.set_kind("pause" if playing else "play")
	viz.active = playing
